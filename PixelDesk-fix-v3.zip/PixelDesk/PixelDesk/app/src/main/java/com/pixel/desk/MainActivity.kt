package com.pixel.desk

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.provider.CalendarContract
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.app.WallpaperManager
import android.graphics.Color
import android.os.Handler
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.IntentFilter
import android.view.inputmethod.EditorInfo
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.ClipData
import android.content.ClipboardManager
import android.content.res.Configuration
import android.content.res.Resources
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.icu.text.Transliterator
import android.net.Uri
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    class App(val label: String, val key: String, val icon: Drawable, val py: String, val ini: String) {
        val pkg get() = key.substringBefore('/')
    }

    private lateinit var sp: SharedPreferences
    private var all = listOf<App>()
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var pager: Pager
    private lateinit var pagerBox: LinearLayout
    private lateinit var dots: LinearLayout
    private var cur = 0
    private var showingCrash = false
    private var dirty = true
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { dirty = true }
    }
    private lateinit var pillV: TextView
    private var dragApp: App? = null
    private var dragWhere = 1
    private var dragChanged = false
    private var dragMoved = false
    private var dragX0 = -1f
    private var dragY0 = -1f
    private var lastFlip = 0L
    private var pageCount = 1
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var dGrid: GridView
    private lateinit var search: EditText
    private lateinit var recent: LinearLayout
    private lateinit var gd: GestureDetector
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var negative: LinearLayout
    private var negativeOpen = false
    private val widgetHostId = 14001
    private val reqWidgetConfigure = 9101
    private val reqWidgetBind = 9102
    private var pendingWidgetId = -1
    private var drawerOpen = false
    private var menuShown = false
    private val tr by lazy { try { Transliterator.getInstance("Han-Latin;Latin-ASCII") } catch (e: Exception) { null } }

    private val layouts = listOf(4 to 5, 4 to 6, 5 to 5, 5 to 6)
    private val sizes = listOf(48, 56, 64, 72)
    private val docks = listOf(3, 4, 5)
    private val shapes = listOf("圆形", "圆角", "原生比例")
    private val themes = listOf("跟随系统", "深色", "浅色")
    private val cols get() = layouts[gi("layout", 0)].first
    private val rows get() = layouts[gi("layout", 0)].second
    private val dark get() = when (gi("theme", 0)) {
        1 -> true; 2 -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    // 负一屏专用：橄榄绿 + 米黄配色（匹配日历小组件风格）
    private val negBg       = 0xFF121810.toInt()          // 深橄榄底
    private val negCard     = 0xFF1E2A1C.toInt()          // 卡片深绿橄榄
    private val negCardAlt  = 0xFF243022.toInt()          // 稍亮卡片
    private val negAccent   = 0xFFA8B88A.toInt()          // 柔和橄榄绿强调
    private val negCream    = 0xFFF5EDE0.toInt()          // 米黄/奶油色
    private val negTextMain = 0xFFF5F0E6.toInt()          // 暖白主文字
    private val negTextSub  = 0xFFA8A890.toInt()          // 暖灰副文字
    private val negStroke   = 0x33A8B88A.toInt()          // 淡绿描边

    private val tints = listOf("壁纸取色", "系统 Material You", "默认蓝")
    private val blurNames = listOf("关", "中", "强")
    private val blurDp = listOf(0, 24, 48)
    private var curBlur = 0f
    private var curScrim = 0f
    private var blurAnim: ValueAnimator? = null
    private val colorsListener = WallpaperManager.OnColorsChangedListener { _, _ -> refresh() }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.argb(Color.alpha(a), ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    private val seed: Int? get() {
        if (gi("tint", 0) != 0) return null
        return try {
            WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)?.primaryColor?.toArgb()
        } catch (e: Exception) { null }
    }

    private val accent: Int get() {
        val s = seed
        return when {
            s != null -> if (dark) mix(s or 0xFF000000.toInt(), Color.WHITE, 0.4f) else mix(s or 0xFF000000.toInt(), Color.BLACK, 0.1f)
            gi("tint", 0) != 2 && Build.VERSION.SDK_INT >= 31 -> try { getColor(android.R.color.system_accent1_200) } catch (e: Exception) { 0xFFB4C5FF.toInt() }
            else -> 0xFFB4C5FF.toInt()
        }
    }

    private fun applyBlur(px: Int) {
        if (Build.VERSION.SDK_INT >= 31) try {
            if (windowManager.isCrossWindowBlurEnabled) window.setBackgroundBlurRadius(px)
        } catch (e: Exception) {}
    }

    private fun animateBlur(open: Boolean) {
        val target = if (open) dp(blurDp[gi("blur", 1)]).toFloat() else 0f
        val scrimT = if (open) 0x66 else 0
        blurAnim?.cancel()
        val b0 = curBlur; val s0 = curScrim
        blurAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur(if (open) 360L else 280L)
            addUpdateListener {
                val f = it.animatedFraction
                curBlur = b0 + (target - b0) * f
                curScrim = s0 + (scrimT - s0) * f
                root.setBackgroundColor(Color.argb(curScrim.toInt(), 0, 0, 0))
                applyBlur(curBlur.toInt())
            }
            start()
        }
    }

    private fun list(k: String): MutableList<String> = try {
        (sp.getString(k, "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableList()
    } catch (e: ClassCastException) {
        sp.edit().remove(k).apply(); mutableListOf()
    }
    private fun save(k: String, l: List<String>) = sp.edit().putString(k, l.joinToString(",")).apply()
    private fun gi(k: String, d: Int): Int {
        return try {
            sp.getInt(k, d)
        } catch (e: ClassCastException) {
            val v = sp.getString(k, null)?.toIntOrNull()
            if (v != null) { sp.edit().putInt(k, v).apply(); v } else d
        } catch (e: Exception) { d }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = dp(r).toFloat()
        // Softer iOS-like stroke
        setStroke(dp(1), 0x22FFFFFF)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("pixel_desk", Context.MODE_PRIVATE)
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { sp.edit().putString("crash", Log.getStackTraceString(e).take(2500)).commit() } catch (t: Throwable) {}
            android.os.Process.killProcess(android.os.Process.myPid())
            System.exit(10)
        }
        val crash = sp.getString("crash", null)
        if (crash != null) {
            sp.edit().remove("crash").commit()
            showingCrash = true
            setContentView(ScrollView(this).apply {
                setBackgroundColor(Color.WHITE)
                addView(TextView(context).apply {
                    text = "上次崩溃信息（请截图发给开发者）：\n\n" + crash
                    setTextColor(Color.BLACK); textSize = 12f
                    setPadding(dp(16), dp(48), dp(16), dp(16)); setTextIsSelectable(true)
                })
            })
            return
        }
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = 0; window.navigationBarColor = 0
        widgetHost = AppWidgetHost(this, widgetHostId)
        widgetHost.startListening()
        buildUi()
        try {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(pkgReceiver, f)
        } catch (e: Exception) {}
        try { WallpaperManager.getInstance(this).addOnColorsChangedListener(colorsListener, Handler(mainLooper)) } catch (e: Exception) {}
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (!drawerOpen && Math.abs(dx) > dp(90) && Math.abs(dx) > Math.abs(dy) * 1.35f && Math.abs(vx) > 700) {
                    if (dx > 0) openNegative(true) else openNegative(false)
                    return true
                }
                if (!drawerOpen && !negativeOpen && dy < -dp(80) && vy < -800 && gi("g_up", 0) == 0) openDrawer(true)
                else if (drawerOpen && dy > dp(80) && vy > 800 && (dGrid.firstVisiblePosition == 0) &&
                    (dGrid.getChildAt(0)?.top ?: 0) >= 0) openDrawer(false)
                else if (!drawerOpen && dy > dp(80) && vy > 800 && Math.abs(dy) > Math.abs(e2.x - e1.x) * 1.5f) downGesture()
                return false
            }
            override fun onLongPress(e: MotionEvent) {
                root.postDelayed({ if (!menuShown && !drawerOpen) showSettings() }, 60)
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (onEmptyHome(e.rawX, e.rawY)) when (gi("g_dbl", 0)) {
                    1 -> lockScreen()
                    2 -> showSettings()
                }
                return false
            }
        })
    }

    override fun onDestroy() {
        try { widgetHost.stopListening() } catch (e: Exception) {}
        super.onDestroy()
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}
        try { WallpaperManager.getInstance(this).removeOnColorsChangedListener(colorsListener) } catch (e: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (showingCrash) return
        if (dirty || all.isEmpty()) load()
        refresh()
        if (!sp.contains("hinted")) {
            sp.edit().putBoolean("hinted", true).apply()
            Toast.makeText(this, "上滑打开应用抽屉；长按图标可添加到桌面，长按空白处进入设置", Toast.LENGTH_LONG).show()
        }
    }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (showingCrash) return super.dispatchTouchEvent(ev)
        if (ev.action == MotionEvent.ACTION_DOWN) menuShown = false
        gd.onTouchEvent(ev); return super.dispatchTouchEvent(ev)
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (showingCrash) { finish(); return }
        if (drawerOpen) { openDrawer(false); return }
        if (negativeOpen) { openNegative(false); return }
    }
    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (showingCrash) return
        if (drawerOpen) openDrawer(false)
        else if (negativeOpen) openNegative(false)
        else if (cur != 0) { cur = 0; pager.smoothScrollTo(0, 0); drawDots() }
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setOnDragListener { _, ev -> onDrag(ev) }
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pillV = TextView(this).apply {
            text = "🔍  搜索应用…"; setTextColor(0xFFFFFFFF.toInt()); textSize = 15.5f
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(24), 0, dp(24), 0)
            // More pill-like iOS search
            background = glass(0x2AFFFFFF, 30); setOnClickListener { openDrawer(true) }
        }
        home.addView(pillV, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(dp(22), dp(20), dp(22), dp(10)) })
        pagerBox = LinearLayout(this)
        pager = Pager(this).apply {
            addView(pagerBox, FrameLayout.LayoutParams(-2, -1))
            onPage = { cur = it; drawDots() }
        }
        home.addView(pager, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(10), 0, dp(10), 0) })
        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        home.addView(dots, LinearLayout.LayoutParams(-1, dp(18)))
        // iOS-style dock: higher corner, more translucent, more height & margin
        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            minimumHeight = dp(98)
            background = glass(0x2EFFFFFF, 38)
        }
        home.addView(dock, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(18), dp(6), dp(18), dp(20)) })
        root.addView(home, FrameLayout.LayoutParams(-1, -1))

        negative = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(24))
            visibility = View.GONE
            // 橄榄绿深色底，匹配小组件风格
            background = GradientDrawable().apply { setColor(negBg) }
        }
        root.addView(negative, FrameLayout.LayoutParams(-1, -1))
        buildNegative()

        drawer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true }
        search = EditText(this).apply {
            hint = "搜索应用 / 拼音 / 首字母"; setSingleLine(); setPadding(dp(22), 0, dp(22), 0)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> drawerApps.firstOrNull()?.let { launch(it) }; true }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { refreshDrawer() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        drawer.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(dp(8), dp(4), dp(8), dp(8)) })
        recent = LinearLayout(this)
        drawer.addView(recent, LinearLayout.LayoutParams(-1, -2))
        dGrid = GridView(this).apply {
            setSelector(android.R.color.transparent); isFastScrollEnabled = true
            setOnItemClickListener { _, _, p, _ -> launch((adapter as Ad).data[p]) }
            setOnItemLongClickListener { _, _, p, _ -> menuShown = true; menu((adapter as Ad).data[p], 0); true }
        }
        drawer.addView(dGrid, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        root.post { drawer.translationY = root.height.toFloat() }
        root.setOnApplyWindowInsetsListener { _, i ->
            // 即使状态栏隐藏（inset=0），也保留最小安全边距，避免顶部缺一块
            val top = maxOf(i.systemWindowInsetTop, dp(12))
            val bot = maxOf(i.systemWindowInsetBottom, dp(8))
            home.setPadding(0, top, 0, bot)
            drawer.setPadding(dp(12), top + dp(8), dp(12), bot)
            negative.setPadding(dp(18), top + dp(8), dp(18), bot + dp(8))
            i
        }
        setContentView(root)
    }

    private fun openNegative(open: Boolean) {
        if (drawerOpen) return
        negativeOpen = open
        negative.visibility = if (open) View.VISIBLE else View.GONE
        if (open) {
            negative.alpha = 0f
            negative.animate().alpha(1f).setDuration(dur(280))
                .setInterpolator(DecelerateInterpolator()).start()
            refreshNegative()
        }
    }

    private fun buildNegative() {
        negative.removeAllViews()
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "发现"; textSize = 28f; setTextColor(negCream)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        head.addView(TextView(this).apply {
            text = "＋"; textSize = 22f; gravity = Gravity.CENTER
            setTextColor(negBg)
            background = GradientDrawable().apply {
                setColor(negCream); cornerRadius = dp(22).toFloat()
            }
            setPadding(0, 0, 0, 0)
            setOnClickListener { showWidgetPicker() }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        negative.addView(head)
        negative.addView(TextView(this).apply {
            text = "向右滑进入负一屏 · 长按小部件可删除"; textSize = 12f
            setTextColor(negTextSub)
            setPadding(dp(4), 0, 0, dp(10))
        })
        val sc = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sc.addView(box, FrameLayout.LayoutParams(-1, -2))
        negative.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        refreshNegative()
    }

    private fun refreshNegative() {
        if (!::negative.isInitialized) return
        val sc = negative.getChildAt(2) as? ScrollView ?: return
        val box = sc.getChildAt(0) as? LinearLayout ?: return
        box.removeAllViews()
        cardsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(cardsBox, LinearLayout.LayoutParams(-1, -2))
        renderCards()
        maybeLoadWeather()
        val ids = list("widgets").mapNotNull { it.toIntOrNull() }
        if (ids.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "\n\n      ＋\n\n添加你常用的小部件\n天气 · 日历 · 音乐 · 电池 · 待办 · 时钟"
                gravity = Gravity.CENTER; textSize = 16f
                setTextColor(negTextSub)
                background = GradientDrawable().apply {
                    setColor(negCard); cornerRadius = dp(28).toFloat()
                    setStroke(dp(1), negStroke)
                }
                setOnClickListener { showWidgetPicker() }
            }, LinearLayout.LayoutParams(-1, dp(250)).apply { setMargins(0, dp(8), 0, dp(10)) })
        } else {
            ids.forEach { id ->
                try {
                    val v = widgetHost.createView(this, id, AppWidgetManager.getInstance(this).getAppWidgetInfo(id))
                    v.setPadding(dp(6), dp(6), dp(6), dp(6))
                    v.background = GradientDrawable().apply {
                        setColor(negCard); cornerRadius = dp(26).toFloat()
                        setStroke(dp(1), negStroke)
                    }
                    v.setOnLongClickListener { removeWidget(id); true }
                    box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) })
                } catch (e: Exception) { removeWidget(id) }
            }
        }
    }

    private fun showWidgetPicker() {
        val providers = AppWidgetManager.getInstance(this).installedProviders.sortedBy { it.label?.toString()?.lowercase() ?: "" }
        if (providers.isEmpty()) { Toast.makeText(this, "没有可用的小部件", Toast.LENGTH_SHORT).show(); return }
        val labels = providers.map { "${it.loadLabel(packageManager)}  ·  ${it.provider.packageName}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("添加小部件").setItems(labels) { _, which -> addWidget(providers[which]) }
            .setNegativeButton("取消", null).show()
    }

    private fun addWidget(info: AppWidgetProviderInfo) {
        val manager = AppWidgetManager.getInstance(this)
        val id = widgetHost.allocateAppWidgetId()
        if (!manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            pendingWidgetId = id
            try {
                startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                }, reqWidgetBind)
            } catch (e: Exception) { widgetHost.deleteAppWidgetId(id); pendingWidgetId = -1; Toast.makeText(this, "此小部件需要系统授权", Toast.LENGTH_SHORT).show() }
            return
        }
        finishAddWidget(id, info)
    }

    private fun finishAddWidget(id: Int, info: AppWidgetProviderInfo) {
        pendingWidgetId = id
        if (info.configure != null) {
            try { startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply { component = info.configure; putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id) }, reqWidgetConfigure) } catch (e: Exception) { saveWidget(id); pendingWidgetId = -1 }
        } else { saveWidget(id); pendingWidgetId = -1 }
    }

    private fun saveWidget(id: Int) {
        val l = list("widgets"); if (id !in l.mapNotNull { it.toIntOrNull() }) { l.add(id.toString()); save("widgets", l) }
        refreshNegative()
    }

    private fun removeWidget(id: Int) {
        try { widgetHost.deleteAppWidgetId(id) } catch (e: Exception) {}
        save("widgets", list("widgets").filter { it != id.toString() }); refreshNegative()
    }

    // ---------- 应用锁（使用系统锁屏验证） ----------
    private val reqAuth = 9301
    private var authApp: App? = null

    private fun toggleLock(a: App) {
        val l = list("locked")
        if (a.key in l) l.remove(a.key) else l.add(a.key)
        save("locked", l)
        Toast.makeText(this, if (a.key in l) "已加应用锁" else "已解除应用锁", Toast.LENGTH_SHORT).show()
    }

    private fun requireAuth(a: App) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) {
            Toast.makeText(this, "请先在系统设置里设置锁屏密码或指纹，应用锁才能生效", Toast.LENGTH_LONG).show()
            return
        }
        @Suppress("DEPRECATION")
        val i = km.createConfirmDeviceCredentialIntent("解锁 " + a.label, "验证后打开应用")
        if (i == null) { launchNow(a); return }
        authApp = a
        try { startActivityForResult(i, reqAuth) } catch (e: Exception) { authApp = null }
    }

    // ---------- 负一屏内置卡片 ----------
    private lateinit var cardsBox: LinearLayout
    private val reqCal = 9302
    private val textMain get() = if (dark) Color.WHITE else 0xFF17202A.toInt()
    private val textSub get() = if (dark) 0xAAFFFFFF.toInt() else 0xFF68727D.toInt()

    // 负一屏卡片专用文字色（橄榄绿米黄风格）
    private val negMain get() = negTextMain
    private val negSub get() = negTextSub

    private fun card(title: String, body: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(negCard)
            cornerRadius = dp(24).toFloat()
            setStroke(dp(1), negStroke)
        }
        addView(TextView(context).apply {
            text = title; textSize = 12f; setTextColor(negAccent)
        })
        addView(body)
    }

    private fun renderCards() {
        if (!::cardsBox.isInitialized) return
        cardsBox.removeAllViews()
        fun lp() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }
        cardsBox.addView(card("🌤  天气", weatherBody()).apply { setOnClickListener { onWeatherTap() } }, lp())
        cardsBox.addView(card("📅  日历", calendarBody()).apply { setOnClickListener { askCalendar() } }, lp())
        cardsBox.addView(card("🔋  电池", batteryBody()), lp())
        cardsBox.addView(card("📝  待办", todoBody()), lp())
    }

    private fun askCalendar() {
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), reqCal)
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(rc, perms, results)
        if (rc == reqCal) renderCards()
        if (rc == reqLoc) { renderCards(); maybeLoadWeather() }
    }

    private fun calendarBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val now = java.util.Date()
        box.addView(TextView(this).apply {
            text = java.text.SimpleDateFormat("M月d日", java.util.Locale.CHINA).format(now)
            textSize = 30f; setTextColor(negMain); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = java.text.SimpleDateFormat("EEEE", java.util.Locale.CHINA).format(now)
            textSize = 14f; setTextColor(negSub)
        })
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            box.addView(TextView(this).apply { text = "点击卡片授权，显示近期日程"; textSize = 13f; setTextColor(negSub); setPadding(0, dp(8), 0, 0) })
            return box
        }
        try {
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, now.time); ContentUris.appendId(b, now.time + 3L * 86400000L)
            contentResolver.query(b.build(), arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
                null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
                val f = java.text.SimpleDateFormat("M/d HH:mm", java.util.Locale.CHINA)
                var n = 0
                while (c.moveToNext() && n < 3) {
                    val line = f.format(java.util.Date(c.getLong(1))) + "  " + (c.getString(0) ?: "（无标题）")
                    box.addView(TextView(this).apply { text = line; textSize = 14f; setTextColor(negMain); setPadding(0, dp(6), 0, 0) })
                    n++
                }
                if (n == 0) box.addView(TextView(this).apply { text = "近 3 天没有日程"; textSize = 13f; setTextColor(negSub); setPadding(0, dp(8), 0, 0) })
            }
        } catch (e: Exception) {}
        return box
    }

    private fun batteryBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else 0
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        box.addView(TextView(this).apply {
            text = "$pct%  ·  " + (if (charging) "充电中" else "未充电") + "  ·  " + temp + "°C"
            textSize = 18f; setTextColor(negMain)
        })
        box.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = pct
            progressTintList = android.content.res.ColorStateList.valueOf(negAccent)
        }, LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(10) })
        return box
    }

    private fun todos(): MutableList<String> =
        (sp.getString("todos", "") ?: "").split("\n").filter { it.length > 2 }.toMutableList()

    private fun saveTodos(l: List<String>) { sp.edit().putString("todos", l.joinToString("\n")).apply() }

    private fun todoBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        todos().forEachIndexed { idx, raw ->
            val done = raw.startsWith("1|")
            val label = raw.substring(2)
            box.addView(TextView(this).apply {
                text = (if (done) "☑  " else "☐  ") + label
                textSize = 15f; setTextColor(if (done) negSub else negMain)
                if (done) paintFlags = paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener {
                    val l = todos()
                    if (idx < l.size) { l[idx] = (if (done) "0|" else "1|") + label; saveTodos(l); renderCards() }
                }
                setOnLongClickListener {
                    val l = todos()
                    if (idx < l.size) { l.removeAt(idx); saveTodos(l); renderCards() }
                    true
                }
            })
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            hint = "添加待办…"; setSingleLine(); textSize = 15f; setTextColor(negMain); setHintTextColor(negSub)
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply {
            text = "添加"; textSize = 15f; setTextColor(negAccent); setPadding(dp(14), dp(10), dp(6), dp(10))
            setOnClickListener {
                val t = input.text.toString().trim().replace("\n", " ")
                if (t.isNotEmpty()) { val l = todos(); l.add("0|" + t); saveTodos(l); renderCards() }
            }
        })
        box.addView(row)
        return box
    }

    // ---------- 天气卡片（小米天气接口，取自你提供的天气应用） ----------
    private val reqLoc = 9303
    private var wxFetching = false
    private val wxCodes = mapOf(0 to "晴", 1 to "多云", 2 to "阴", 3 to "阵雨", 4 to "雷阵雨", 5 to "雷阵雨伴冰雹",
        6 to "雨夹雪", 7 to "小雨", 8 to "中雨", 9 to "大雨", 10 to "暴雨", 11 to "大暴雨", 12 to "特大暴雨",
        13 to "阵雪", 14 to "小雪", 15 to "中雪", 16 to "大雪", 17 to "暴雪", 18 to "雾", 19 to "冻雨",
        20 to "沙尘暴", 29 to "浮尘", 30 to "扬沙", 31 to "强沙尘暴", 32 to "浓雾", 49 to "强浓雾",
        53 to "霾", 54 to "中度霾", 55 to "重度霾", 56 to "严重霾", 57 to "大雾", 58 to "特强浓雾", 301 to "雨", 302 to "雪")

    private fun hasLoc() = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun onWeatherTap() {
        if (!hasLoc()) { requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), reqLoc); return }
        val i = listOf("com.weather.app", "com.miui.weather2").firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else Toast.makeText(this, "没找到天气应用", Toast.LENGTH_SHORT).show()
    }

    private fun weatherBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val p = (sp.getString("wx", null) ?: "").split("|")
        if (p.size < 9) {
            box.addView(TextView(this).apply {
                text = if (hasLoc()) "正在获取天气…" else "点击卡片授权定位，显示当地天气"
                textSize = 14f; setTextColor(negSub); setPadding(0, dp(6), 0, 0)
            })
            return box
        }
        val row = LinearLayout(this).apply { gravity = Gravity.BOTTOM }
        row.addView(TextView(this).apply {
            text = p[1] + "°"; textSize = 42f; setTextColor(negMain); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        row.addView(TextView(this).apply { text = "  " + p[2]; textSize = 18f; setTextColor(negMain); setPadding(0, 0, 0, dp(8)) })
        box.addView(row)
        box.addView(TextView(this).apply {
            text = p[0] + "  ·  最高" + p[6] + "°  最低" + p[7] + "°"; textSize = 14f; setTextColor(negSub)
        })
        box.addView(TextView(this).apply {
            text = "体感" + p[3] + "°  ·  湿度" + p[4] + "%" + (if (p[5].isNotBlank()) "  ·  空气 " + p[5] else "")
            textSize = 14f; setTextColor(negSub); setPadding(0, dp(4), 0, 0)
        })
        return box
    }

    private fun lastLoc(): android.location.Location? {
        val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        var best: android.location.Location? = null
        for (prov in lm.getProviders(true)) {
            try {
                val l = lm.getLastKnownLocation(prov)
                if (l != null && (best == null || l.time > best.time)) best = l
            } catch (e: SecurityException) {}
        }
        return best
    }

    private fun maybeLoadWeather() {
        if (wxFetching || !hasLoc()) return
        if (System.currentTimeMillis() - sp.getLong("wx_t", 0L) < 20 * 60 * 1000L) return
        val l = lastLoc()
        if (l != null) { fetchWeather(l.latitude, l.longitude); return }
        if (Build.VERSION.SDK_INT >= 30) {
            val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            val prov = lm.getProviders(true).firstOrNull { it != android.location.LocationManager.PASSIVE_PROVIDER } ?: return
            try {
                lm.getCurrentLocation(prov, null, mainExecutor) { loc -> if (loc != null) fetchWeather(loc.latitude, loc.longitude) }
            } catch (e: SecurityException) {}
        }
    }

    private fun http(u: String): String {
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Mobile")
        c.setRequestProperty("Accept", "application/json")
        try { return c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    private fun fetchWeather(lat: Double, lon: Double) {
        if (wxFetching) return
        wxFetching = true
        Thread {
            try {
                val base = "https://weatherapi.market.xiaomi.com/wtr-v3/"
                var key = "weathercn:" + String.format(java.util.Locale.US, "%.3f,%.3f", lon, lat)
                var name = "当前位置"
                try {
                    val g = org.json.JSONArray(http(base + "location/city/geo?latitude=" + lat + "&longitude=" + lon + "&locale=zh_cn"))
                    if (g.length() > 0) {
                        val o = g.getJSONObject(0)
                        key = o.optString("locationKey", key); name = o.optString("name", name)
                    }
                } catch (e: Exception) {}
                val q = "latitude=" + lat + "&longitude=" + lon + "&locationKey=" + java.net.URLEncoder.encode(key, "UTF-8") +
                    "&days=15&appKey=weather20151024&sign=zUFJoAR2ZVrDy1vF3D07&isGlobal=false&isLocated=true&locale=zh_cn"
                val j = org.json.JSONObject(http(base + "weather/all?" + q))
                val cur = j.getJSONObject("current")
                fun v(o: org.json.JSONObject?, k: String): String = o?.optJSONObject(k)?.optString("value", "") ?: ""
                val temp = Math.round(v(cur, "temperature").toDoubleOrNull() ?: 0.0)
                val feels = Math.round(v(cur, "feelsLike").toDoubleOrNull() ?: temp.toDouble())
                val hum = Math.round(v(cur, "humidity").toDoubleOrNull() ?: 0.0)
                val text = wxCodes[cur.optString("weather", "1").toIntOrNull() ?: 1] ?: "多云"
                val aqi = j.optJSONObject("aqi")?.optString("aqi", "") ?: ""
                val dt = j.optJSONObject("forecastDaily")?.optJSONObject("temperature")?.optJSONArray("value")
                val hi = dt?.optJSONObject(0)?.optString("from", "") ?: ""
                val lo = dt?.optJSONObject(0)?.optString("to", "") ?: ""
                val line = listOf(name.replace("|", ""), temp.toString(), text, feels.toString(), hum.toString(), aqi, hi, lo, "ok").joinToString("|")
                sp.edit().putString("wx", line).putLong("wx_t", System.currentTimeMillis()).apply()
            } catch (e: Exception) {
            }
            runOnUiThread { wxFetching = false; if (negativeOpen) renderCards() }
        }.start()
    }

    private fun customApp(a: App) {
        val opts = arrayOf("修改桌面名称", "从相册选择图标", "从图标包选择", "恢复默认图标/名称")
        AlertDialog.Builder(this).setTitle("自定义 · ${displayLabel(a)}").setItems(opts) { _, i ->
            when (i) {
                0 -> renameApp(a)
                1 -> pickAppIcon(a)
                2 -> pickPackIcon(a)
                3 -> { sp.edit().remove("label:${a.key}").remove("icon:${a.key}").remove("packicon:${a.key}").apply(); load(); refresh() }
            }
        }.show()
    }

    private fun displayLabel(a: App) = sp.getString("label:${a.key}", null) ?: a.label

    private fun renameApp(a: App) {
        val input = EditText(this).apply { setSingleLine(); setText(displayLabel(a)); selectAll() }
        AlertDialog.Builder(this).setTitle("修改桌面名称").setView(input).setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ -> sp.edit().putString("label:${a.key}", input.text.toString().trim().ifEmpty { a.label }).apply(); load(); refresh() }.show()
    }

    private val reqAppIcon = 9103
    private var pendingAppKey = ""
    private fun pickAppIcon(a: App) {
        pendingAppKey = a.key
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), reqAppIcon) }
        catch (e: Exception) { Toast.makeText(this, "找不到图片选择器", Toast.LENGTH_SHORT).show() }
    }

    private fun pickPackIcon(a: App) {
        if (packRes == null || packMap.isEmpty()) { Toast.makeText(this, "请先在设置里启用图标包", Toast.LENGTH_SHORT).show(); return }
        val names = packMap.entries.filter { it.key.substringBefore('/') == a.pkg }.map { it.value }.distinct()
        if (names.isEmpty()) { Toast.makeText(this, "这个图标包没有提供该应用的可选图标", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("选择 ${displayLabel(a)} 图标").setItems(names.toTypedArray()) { _, which ->
            sp.edit().putString("packicon:${a.key}", names[which]).apply(); load(); refresh()
        }.show()
    }

    private fun pinyin(s: String): Pair<String, String> {
        val t = try { tr?.transliterate(s) ?: s } catch (e: Exception) { s }
        val w = t.lowercase().split(" ").filter { it.isNotEmpty() }
        return w.joinToString("") to w.map { it[0] }.joinToString("")
    }

    // ---------- 图标包 ----------
    private var packRes: Resources? = null
    private var packPkg = ""
    private val packMap = HashMap<String, String>()

    private fun packs(): List<Pair<String, String>> {
        val acts = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME",
            "com.gau.go.launcherex.theme", "app.lawnchair.icons.THEMED_ICON")
        return acts.flatMap { packageManager.queryIntentActivities(Intent(it), 0) }
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
    }

    private fun loadPack() {
        packMap.clear(); packRes = null; packPkg = ""
        val pkg = sp.getString("pack", "") ?: ""
        if (pkg.isEmpty()) return
        try {
            val res = packageManager.getResourcesForApplication(pkg)
            val parser: XmlPullParser = try {
                XmlPullParserFactory.newInstance().newPullParser().also { it.setInput(res.assets.open("appfilter.xml"), null) }
            } catch (e: Exception) {
                res.getXml(res.getIdentifier("appfilter", "xml", pkg))
            }
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                    val c = parser.getAttributeValue(null, "component")
                    val d = parser.getAttributeValue(null, "drawable")
                    if (c != null && d != null && c.startsWith("ComponentInfo{")) {
                        val k = c.removePrefix("ComponentInfo{").removeSuffix("}")
                        val pk = k.substringBefore('/')
                        var cl = k.substringAfter('/', "")
                        if (cl.startsWith(".")) cl = pk + cl
                        if (cl.isNotEmpty()) packMap["$pk/$cl"] = d
                    }
                }
                ev = parser.next()
            }
            packRes = res; packPkg = pkg
        } catch (e: Exception) { packRes = null }
    }

    private fun packIcon(key: String): Drawable? {
        val r = packRes ?: return null
        val n = packMap[key] ?: return null
        val id = r.getIdentifier(n, "drawable", packPkg)
        if (id == 0) return null
        return try { r.getDrawable(id, null) } catch (e: Exception) { null }
    }

    private fun showPacks() {
        val p = packs()
        if (p.isEmpty()) { Toast.makeText(this, "未检测到图标包，请先安装", Toast.LENGTH_LONG).show(); return }
        val names = (listOf("系统默认") + p.map { it.first }).toTypedArray()
        AlertDialog.Builder(this).setTitle("图标包").setItems(names) { _, i ->
            sp.edit().putString("pack", if (i == 0) "" else p[i - 1].second).apply()
            load(); refresh()
        }.show()
    }

    // ---------- 备份 / 恢复 ----------
    private fun backup() {
        val j = JSONObject(); sp.all.forEach { (k, v) -> j.put(k, v) }
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("pixel_desk", j.toString()))
        Toast.makeText(this, "布局已复制到剪贴板，请自行粘贴保存", Toast.LENGTH_LONG).show()
    }

    private fun restore() {
        try {
            val t = (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .primaryClip?.getItemAt(0)?.text.toString()
            val j = JSONObject(t); val e = sp.edit()
            j.keys().forEach { k ->
                when (val v = j.get(k)) {
                    is Int -> e.putInt(k, v)
                    is Boolean -> e.putBoolean(k, v)
                    is String -> e.putString(k, v)
                    else -> {}
                }
            }
            e.apply(); load(); refresh()
            Toast.makeText(this, "已恢复", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "剪贴板里没有有效备份", Toast.LENGTH_SHORT).show() }
    }

    private fun load() {
        dirty = false
        loadPack()
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(q, 0).filter { it.activityInfo.packageName != packageName }.map {
            val raw = it.loadLabel(pm).toString(); val key = it.activityInfo.packageName + "/" + it.activityInfo.name
            val l = sp.getString("label:$key", raw) ?: raw; val (p, i) = pinyin(l)
            val overrideName = sp.getString("packicon:$key", null)
            val overrideIcon = if (overrideName != null && packRes != null) (try { packRes!!.getDrawable(packRes!!.getIdentifier(overrideName, "drawable", packPkg), null) } catch (e: Exception) { null }) else null
            val uri = sp.getString("icon:$key", null)
            val custom = if (uri != null) (try { contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapDrawable(resources, BitmapFactory.decodeStream(it)) } } catch (e: Exception) { null }) else null
            App(l, key, custom ?: overrideIcon ?: packIcon(key) ?: it.loadIcon(pm), p, i)
        }.sortedBy { it.py }
        if (!sp.contains("dock")) {
            val intents = listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), Intent("android.media.action.IMAGE_CAPTURE"))
            val keys = intents.mapNotNull { pm.resolveActivity(it, 0)?.activityInfo?.packageName }
                .mapNotNull { p -> all.firstOrNull { it.pkg == p }?.key }.distinct()
            save("dock", keys)
        }
    }

    private inner class Ad(val data: List<App>, val color: Int) : BaseAdapter() {
        override fun getCount() = data.size
        override fun getItem(p: Int) = data[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, g: ViewGroup?): View {
            val a = data[p]
            if (v is LinearLayout && v.tag == "cell") {
                v.alpha = 1f
                (v.getChildAt(0) as ImageView).setImageDrawable(a.icon)
                (v.getChildAt(1) as? TextView)?.text = a.label
                return v
            }
            return cell(a, color)
        }
    }

    private fun cell(a: App, color: Int, showLabel: Boolean = true): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        // Slightly more breathing room like iOS
        setPadding(dp(4), dp(12), dp(4), dp(8)); tag = "cell"
        val s = dp(sizes[gi("size", 1)])
        val iv = ImageView(context).apply { setImageDrawable(a.icon) }
        // iOS continuous corner ≈ 0.2237 of side; keep circle option and native
        val r = when (gi("shape", 1)) { 0 -> 0.5f; 1 -> 0.2237f; else -> 0f }
        if (r > 0f) {
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, v.width * r)
                }
            }
            iv.clipToOutline = true
        }
        addView(iv, LinearLayout.LayoutParams(s, s))
        if (showLabel && sp.getBoolean("label", true)) addView(TextView(context).apply {
            text = a.label; setTextColor(color); textSize = 11.5f; maxLines = 1; gravity = Gravity.CENTER
            ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(5), 0, 0)
            if (color == 0xFFFFFFFF.toInt()) setShadowLayer(3.5f, 0f, 1.2f, 0xAA000000.toInt())
        })
    }

    private inner class Pager(c: Context) : HorizontalScrollView(c) {
        var onPage: (Int) -> Unit = {}
        private var flung = false
        init { isHorizontalScrollBarEnabled = false; overScrollMode = OVER_SCROLL_NEVER }
        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.action == MotionEvent.ACTION_DOWN) flung = false
            val r = super.onTouchEvent(ev)
            if ((ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) && !flung) snap(0)
            return r
        }
        override fun fling(velocityX: Int) { flung = true; snap(velocityX) }
        private fun snap(v: Int) {
            val w = width
            if (w == 0) return
            val c = scrollX.toFloat() / w
            var t = when {
                v > 600 -> Math.ceil(c.toDouble()).toInt()
                v < -600 -> Math.floor(c.toDouble()).toInt()
                else -> Math.round(c)
            }
            t = t.coerceIn(0, pageCount - 1)
            smoothScrollTo(t * w, 0); onPage(t)
        }
    }

    private fun buildPages(apps: List<App>) {
        val ps = cols * rows
        pageCount = maxOf(1, (apps.size + ps - 1) / ps)
        cur = cur.coerceIn(0, pageCount - 1)
        val pw = resources.displayMetrics.widthPixels - dp(20)
        pagerBox.removeAllViews()
        for (i in 0 until pageCount) pagerBox.addView(GridView(this).apply {
            numColumns = cols
            // More vertical breathing room like iOS
            verticalSpacing = dp(14)
            horizontalSpacing = dp(4)
            setSelector(android.R.color.transparent)
            adapter = Ad(apps.drop(i * ps).take(ps), 0xFFFFFFFF.toInt())
            setOnItemClickListener { _, _, p, _ -> launch((adapter as Ad).data[p]) }
            setOnItemLongClickListener { _, v, p, _ -> menuShown = true; startDrag((adapter as Ad).data[p], 1, v); true }
        }, LinearLayout.LayoutParams(pw, -1))
        pager.post { pager.scrollTo(cur * pw, 0) }
        drawDots()
    }

    private fun drawDots() {
        dots.removeAllViews()
        if (pageCount < 2 || !sp.getBoolean("dots", true)) return
        for (i in 0 until pageCount) dots.addView(View(this).apply {
            background = GradientDrawable().apply {
                setColor(if (i == cur) 0xFFFFFFFF.toInt() else 0x55FFFFFF)
                cornerRadius = dp(4).toFloat()
            }
        }, LinearLayout.LayoutParams(if (i == cur) dp(18) else dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
    }

    // ---------- 拖拽排序 ----------
    private fun startDrag(a: App, where: Int, v: View) {
        dragApp = a; dragWhere = where; dragChanged = false; dragMoved = false; dragX0 = -1f
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        v.startDragAndDrop(ClipData.newPlainText("app", a.key), View.DragShadowBuilder(v), null, 0)
        v.alpha = 0.3f
    }

    private fun flip(p: Int) {
        cur = p; lastFlip = System.currentTimeMillis()
        pager.smoothScrollTo(p * pager.width, 0); drawDots()
    }

    private fun onDrag(ev: DragEvent): Boolean {
        when (ev.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                if (dragApp == null) return false
                pillV.text = "✕  拖到此处从桌面移除"
            }
            DragEvent.ACTION_DRAG_LOCATION -> {
                if (dragX0 < 0) { dragX0 = ev.x; dragY0 = ev.y }
                else if (Math.abs(ev.x - dragX0) + Math.abs(ev.y - dragY0) > dp(24)) dragMoved = true
                if (System.currentTimeMillis() - lastFlip > 700) {
                    if (ev.x < dp(36) && cur > 0) flip(cur - 1)
                    else if (ev.x > root.width - dp(36) && cur < pageCount - 1) flip(cur + 1)
                }
            }
            DragEvent.ACTION_DROP -> drop(ev.x, ev.y)
            DragEvent.ACTION_DRAG_ENDED -> {
                pillV.text = "🔍  搜索应用…"
                val a = dragApp; dragApp = null
                refresh()
                if (a != null && !dragChanged && !dragMoved) menu(a, dragWhere)
            }
        }
        return true
    }

    private fun drop(x: Float, y: Float) {
        val a = dragApp ?: return
        val key = a.key
        val vis = all.map { it.key }.toSet() - list("hidden").toSet()
        val hl = list("home"); val dl = list("dock")
        val hv = hl.filter { it in vis }; val dv = dl.filter { it in vis }
        val nh = hv.toMutableList().apply { remove(key) }
        val nd = dv.toMutableList().apply { remove(key) }
        val rl = IntArray(2); root.getLocationInWindow(rl)
        when {
            y < home.getChildAt(0).bottom + dp(12) -> {}   // 拖到顶部：移除
            y > dock.top -> {
                if (nd.size >= docks[gi("dockN", 1)]) {
                    Toast.makeText(this, "Dock 已满", Toast.LENGTH_SHORT).show(); return
                }
                var idx = nd.size
                for (i in 0 until dock.childCount) {
                    val c = dock.getChildAt(i)
                    if (dock.left + c.left + c.width / 2 > x) { idx = i; break }
                }
                nd.add(idx.coerceAtMost(nd.size), key)
            }
            else -> {
                val g = pagerBox.getChildAt(cur) as? GridView ?: return
                val gl = IntArray(2); g.getLocationInWindow(gl)
                val pos = g.pointToPosition((x - (gl[0] - rl[0])).toInt(), (y - (gl[1] - rl[1])).toInt())
                val ps = cols * rows
                val cnt = (hv.size - cur * ps).coerceIn(0, ps)
                val t = cur * ps + (if (pos >= 0) pos else cnt)
                nh.add(t.coerceAtMost(nh.size), key)
            }
        }
        if (nh != hv || nd != dv) {
            save("home", nh + hl.filter { it !in vis }); save("dock", nd + dl.filter { it !in vis })
            dragChanged = true
        }
    }

    private var drawerApps = listOf<App>()
    private fun refresh() {
        val hidden = list("hidden").toSet()
        val vis = all.filter { it.key !in hidden }
        val byKey = vis.associateBy { it.key }
        buildPages(list("home").mapNotNull { byKey[it] })
        dock.background = glass(mix(0x38FFFFFF, accent, 0.22f), 38)
        pillV.visibility = if (sp.getBoolean("pill", true)) View.VISIBLE else View.GONE
        pillV.background = glass(0x2AFFFFFF, 30).also { it.setStroke(dp(1), accent and 0x00FFFFFF or 0x66000000.toInt()) }
        dock.removeAllViews()
        list("dock").mapNotNull { byKey[it] }.take(docks[gi("dockN", 1)]).forEach { a ->
            dock.addView(cell(a, 0xFFFFFFFF.toInt(), showLabel = false).apply {
                setOnClickListener { launch(a) }
                setOnLongClickListener { v -> menuShown = true; startDrag(a, 2, v); true }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val tc = if (dark) 0xFFFFFFFF.toInt() else 0xFF1B1B1F.toInt()
        drawer.background = GradientDrawable().apply {
            setColor(mix(if (dark) 0xE6101014.toInt() else 0xE6FFFFFF.toInt(), accent, if (dark) 0.14f else 0.12f))
            // Softer top corners for drawer
            cornerRadii = floatArrayOf(dp(32).toFloat(), dp(32).toFloat(), dp(32).toFloat(), dp(32).toFloat(), 0f, 0f, 0f, 0f)
        }
        search.setTextColor(tc); search.setHintTextColor(tc and 0x00FFFFFF or 0x88000000.toInt())
        search.background = glass(if (dark) 0x22FFFFFF else 0x14000000, 28).also { it.setStroke(dp(1), accent) }
        refreshDrawer()
    }

    private fun refreshDrawer() {
        val hidden = list("hidden").toSet()
        val q = search.text.toString().trim().lowercase()
        val vis = all.filter { it.key !in hidden }
        drawerApps = if (q.isEmpty()) vis else vis.filter {
            it.label.lowercase().contains(q) || it.py.contains(q) || it.ini.startsWith(q)
        }
        val tc = if (dark) 0xFFFFFFFF.toInt() else 0xFF1B1B1F.toInt()
        dGrid.numColumns = cols
        dGrid.adapter = Ad(drawerApps, tc)
        recent.removeAllViews()
        if (q.isEmpty()) {
            val byKey = vis.associateBy { it.key }
            list("recent").mapNotNull { byKey[it] }.take(cols).forEach { a ->
                recent.addView(cell(a, tc).apply { setOnClickListener { launch(a) } }, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
    }

    private fun launch(a: App) {
        if (a.key in list("locked")) { requireAuth(a); return }
        launchNow(a)
    }

    private fun launchNow(a: App) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName.unflattenFromString(a.key)!!).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Exception) { Toast.makeText(this, "无法打开", Toast.LENGTH_SHORT).show() }
        val r = list("recent"); r.remove(a.key); r.add(0, a.key); save("recent", r.take(5))
        if (drawerOpen) root.postDelayed({ openDrawer(false) }, 300)
    }

    private fun menu(a: App, where: Int) {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items += "自定义图标 / 名称" to { customApp(a) }
        if (where == 0) {
            items += "添加到桌面" to { pin("home", a) }
            items += "添加到 Dock" to { pin("dock", a) }
        } else items += "从桌面移除" to { val l = list(if (where == 1) "home" else "dock"); l.remove(a.key); save(if (where == 1) "home" else "dock", l); refresh() }
        items += "隐藏" to {
            val h = list("hidden"); h.add(a.key); save("hidden", h)
            for (k in listOf("home", "dock")) { val l = list(k); l.remove(a.key); save(k, l) }
            refresh()
        }
        items += (if (a.key in list("locked")) "解除应用锁" else "加应用锁") to { toggleLock(a) }
        items += "应用信息" to { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg))) }
        items += "卸载" to { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))) }
        AlertDialog.Builder(this).setTitle(a.label).setItems(items.map { p -> p.first }.toTypedArray()) { _, i -> items[i].second() }.show()
    }

    private fun pin(k: String, a: App) {
        val l = list(k); if (a.key !in l) l.add(a.key); save(k, l); refresh()
        Toast.makeText(this, "已添加", Toast.LENGTH_SHORT).show()
    }

    // ---------- 手势 / 动画 ----------
    private val upNames = listOf("打开抽屉", "无")
    private val downNames = listOf("通知栏", "打开搜索", "无")
    private val dblNames = listOf("无", "锁屏", "打开设置")
    private val animNames = listOf("快", "标准", "慢", "关闭")
    private val animScales = listOf(0.6f, 1f, 1.5f, 0f)
    private fun dur(ms: Long): Long = (ms * animScales[gi("anim", 1)]).toLong()

    private fun downGesture() {
        when (gi("g_down", 0)) {
            0 -> expandStatusBar()
            1 -> {
                openDrawer(true)
                search.post {
                    search.requestFocus()
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, 0)
                }
            }
        }
    }

    private fun expandStatusBar() {
        try {
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel")
                .invoke(getSystemService("statusbar"))
        } catch (e: Exception) { Toast.makeText(this, "此设备不支持下滑通知栏", Toast.LENGTH_SHORT).show() }
    }

    private fun lockScreen() {
        if (LockService.lock()) return
        AlertDialog.Builder(this).setTitle("需要开启无障碍服务")
            .setMessage("双击锁屏需要在“无障碍”里开启「pixel桌面 锁屏」。该服务只执行锁屏动作，不会读取屏幕内容。")
            .setPositiveButton("去开启") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("取消", null).show()
    }

    private fun onEmptyHome(x: Float, y: Float): Boolean {
        if (drawerOpen) return false
        val g = pagerBox.getChildAt(cur) as? GridView ?: return false
        val gl = IntArray(2); g.getLocationOnScreen(gl)
        val gx = (x - gl[0]).toInt(); val gy = (y - gl[1]).toInt()
        if (gx < 0 || gx > g.width || gy < 0 || gy > g.height) return false
        return g.pointToPosition(gx, gy) == AdapterView.INVALID_POSITION
    }

    private fun cyc(k: String, n: Int, d: Int = 0) { sp.edit().putInt(k, (gi(k, d) + 1) % n).apply(); refresh() }

    private fun showSettings() {
        val e = listOf<Pair<String, () -> Unit>>(
            "桌面布局：${cols}×${rows}" to { cyc("layout", layouts.size) },
            "图标大小：${sizes[gi("size", 1)]}dp" to { cyc("size", sizes.size, 1) },
            "图标标签：${if (sp.getBoolean("label", true)) "开" else "关"}" to { sp.edit().putBoolean("label", !sp.getBoolean("label", true)).apply(); refresh() },
            "图标包：${packs().firstOrNull { it.second == packPkg }?.first ?: "系统默认"}" to { showPacks() },
            "主题色：${tints[gi("tint", 0)]}" to { cyc("tint", tints.size) },
            "壁纸模糊：${blurNames[gi("blur", 1)]}" to { cyc("blur", blurNames.size, 1) },
            "上滑手势：${upNames[gi("g_up", 0)]}" to { cyc("g_up", upNames.size) },
            "下滑手势：${downNames[gi("g_down", 0)]}" to { cyc("g_down", downNames.size) },
            "双击手势：${dblNames[gi("g_dbl", 0)]}" to { cyc("g_dbl", dblNames.size) },
            "动画速度：${animNames[gi("anim", 1)]}" to { cyc("anim", animNames.size, 1) },
            "图标形状：${shapes[gi("shape", 1)]}" to { cyc("shape", shapes.size, 1) },
            "Dock 数量：${docks[gi("dockN", 1)]}" to { cyc("dockN", docks.size, 1) },
            "主题：${themes[gi("theme", 0)]}" to { cyc("theme", themes.size) },
            "负一屏小部件管理" to { openNegative(true) },
            "隐藏应用管理" to { hiddenManager() },
            "页面指示器：${if (sp.getBoolean("dots", true)) "开" else "关"}" to { toggle("dots") },
            "搜索栏：${if (sp.getBoolean("pill", true)) "显示" else "隐藏"}" to { toggle("pill") },
            "备份布局到剪贴板" to { backup() },
            "从剪贴板恢复布局" to { restore() },
            "自定义壁纸（桌面 / 锁屏）" to { pickWallpaper() },
            "系统壁纸选择器" to { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "壁纸")) },
            "设为默认桌面" to { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) },
        )
        AlertDialog.Builder(this).setTitle("pixel桌面 设置")
            .setItems(e.map { it.first }.toTypedArray()) { _, i -> e[i].second() }.show()
    }

    private val reqWallpaper = 77
    private fun toggle(k: String) { sp.edit().putBoolean(k, !sp.getBoolean(k, true)).apply(); refresh() }

    private fun pickWallpaper() {
        try {
            startActivityForResult(Intent.createChooser(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), "选择壁纸"), reqWallpaper)
        } catch (e: Exception) { Toast.makeText(this, "找不到图片选择器", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == reqAuth) {
            val a = authApp; authApp = null
            if (res == RESULT_OK && a != null) launchNow(a)
            return
        }
        if (rc == reqWidgetBind) {
            val id = pendingWidgetId
            if (res == RESULT_OK && id > 0) {
                val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
                if (info != null) finishAddWidget(id, info) else { widgetHost.deleteAppWidgetId(id); pendingWidgetId = -1 }
            } else if (id > 0) { widgetHost.deleteAppWidgetId(id); pendingWidgetId = -1 }
            return
        }
        if (rc == reqWidgetConfigure) {
            val id = pendingWidgetId
            if (id > 0 && res == RESULT_OK) saveWidget(id) else if (id > 0) widgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1; return
        }
        if (rc == reqAppIcon) {
            if (res == RESULT_OK) {
                val uri = data?.data
                if (uri != null && pendingAppKey.isNotEmpty()) {
                    try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
                    sp.edit().putString("icon:$pendingAppKey", uri.toString()).apply(); load(); refresh()
                }
            }
            pendingAppKey = ""; return
        }
        if (rc != reqWallpaper || res != RESULT_OK) return
        val uri = data?.data ?: return
        val labels = arrayOf("桌面", "锁屏", "桌面和锁屏")
        AlertDialog.Builder(this).setTitle("设为").setItems(labels) { _, i ->
            val flag = when (i) {
                0 -> WallpaperManager.FLAG_SYSTEM
                1 -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            Thread {
                val ok = try {
                    contentResolver.openInputStream(uri)?.use { WallpaperManager.getInstance(this).setStream(it, null, true, flag) }
                    true
                } catch (e: Exception) { false }
                runOnUiThread { Toast.makeText(this, if (ok) "壁纸已设置" else "设置失败", Toast.LENGTH_SHORT).show() }
            }.start()
        }.show()
    }

    private fun hiddenManager() {
        val hidden = list("hidden").toSet()
        val checked = BooleanArray(all.size) { all[it].key in hidden }
        AlertDialog.Builder(this).setTitle("隐藏应用")
            .setMultiChoiceItems(all.map { it.label }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("完成") { _, _ -> save("hidden", all.filterIndexed { i, _ -> checked[i] }.map { it.key }); refresh() }
            .show()
    }

    private fun openDrawer(o: Boolean) {
        if (o && negativeOpen) openNegative(false)
        drawerOpen = o
        animateBlur(o)
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (o) {
            search.setText("")
            refreshDrawer()
            if (drawer.visibility != View.VISIBLE) drawer.translationY = root.height.toFloat()
            drawer.visibility = View.VISIBLE
            // Mild overshoot for iOS-like spring feel
            drawer.animate().translationY(0f).setDuration(dur(380))
                .setInterpolator(OvershootInterpolator(1.05f)).start()
            home.animate().alpha(0.32f).scaleX(0.93f).scaleY(0.93f)
                .setDuration(dur(340)).setInterpolator(DecelerateInterpolator()).start()
        } else {
            imm.hideSoftInputFromWindow(search.windowToken, 0)
            drawer.animate().translationY(root.height.toFloat()).setDuration(dur(280))
                .setInterpolator(DecelerateInterpolator())
                .withEndAction { drawer.visibility = View.GONE }.start()
            home.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(dur(280))
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }
}
