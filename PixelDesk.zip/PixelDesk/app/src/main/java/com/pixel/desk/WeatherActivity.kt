package com.pixel.desk

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

/**
 * 内置天气界面：直接使用「天气」应用的网页界面（assets/weather/index.html）和它的数据源，
 * 并提供与原应用相同的本地接口（window.Android）。
 */
// 与原天气应用一致：页面加载完后，如果还停在“加载中 / 正在获取”，就主动触发一次首次取数
private const val BOOT_JS = """(function(){try{if(window.__bootKicked)return;window.__bootKicked=true;var el=document.getElementById('cityName');var c=localStorage.getItem('lastCity')||'';if(el&&(el.textContent==='加载中'||el.textContent==='定位中...'||!el.textContent))el.textContent=c;var box=document.getElementById('content');var h=box?(box.innerHTML||''):'';if(h.indexOf('正在获取')>=0||h.indexOf('loading')>=0||h.length<80){if(window.quickStartWeather)window.quickStartWeather('pageFinished');}}catch(e){}})();"""

// 兜底：如果页面一直停在“首屏已加载，完整界面准备中…”（页面自带的 12 秒检查看不到这种状态），
// 就按页面自己的恢复方式重新加载完整界面，最多 3 次；界面一出来就停止，不会反复刷新。
private const val WATCHDOG_JS = """(function(){try{if(window.__wdOn)return;window.__wdOn=true;var t0=Date.now(),n=0;var iv=setInterval(function(){try{var c=document.getElementById('content');var h=c?(c.innerHTML||''):'';var stuck=h.indexOf('首屏已加载')>=0||h.indexOf('完整界面准备中')>=0;var dt=Date.now()-t0;if(!stuck){if(h.length>300||dt>45000)clearInterval(iv);return;}if(dt<6000)return;if(n>=3){clearInterval(iv);return;}if(n===0||dt>12000*n){n++;window.__wxFlight='';window.__qsLock=0;window.__wxLastLoadAt=0;if(n>=2){try{cfg=setCfg({source:'xiaomi'});}catch(e){}}var la=parseFloat(localStorage.getItem('lastLat')||'');var ln=parseFloat(localStorage.getItem('lastLng')||'');var lc=localStorage.getItem('lastCity')||'';if(isNaN(la)||isNaN(ln)){if(window.quickStartWeather)quickStartWeather('force-watchdog');}else{loadByCoord(la,ln,lc);}}}catch(e){}},1500);}catch(e){}})();"""

class WeatherActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = 0x700
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 7)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.isVerticalScrollBarEnabled = false
        web.overScrollMode = View.OVER_SCROLL_NEVER
        val st = web.settings
        st.javaScriptEnabled = true
        st.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        st.allowContentAccess = true
        st.allowFileAccess = true
        st.allowFileAccessFromFileURLs = true
        st.allowUniversalAccessFromFileURLs = true
        st.domStorageEnabled = true
        st.databaseEnabled = true
        st.cacheMode = WebSettings.LOAD_DEFAULT
        st.setGeolocationEnabled(true)
        st.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val v = view ?: return
                v.evaluateJavascript(BOOT_JS, null)
                v.evaluateJavascript(WATCHDOG_JS, null)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, true, false)
            }
        }
        web.addJavascriptInterface(WeatherBridge(this), "Android")
        web.loadUrl("file:///android_asset/weather/index.html")
        setContentView(web)
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(rc, perms, results)
        if (rc == 7 && results.any { it == PackageManager.PERMISSION_GRANTED }) web.reload()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else finish()
    }

    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}

/** 与原天气应用的 WebAppInterface 对应的接口，网页通过 window.Android 调用。 */
class WeatherBridge(private val ctx: Context) {
    private val ua = "Dalvik/2.1.0 (Linux; U; Android 13; MI 12 Build/TKQ1.220807.001) Weather/1.0"

    private fun get(url: String, timeoutMs: Int = 15000): String {
        var c: HttpURLConnection? = null
        try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = true
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept", "application/json, text/javascript, */*")
            c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9")
            c.setRequestProperty("Accept-Encoding", "identity")
            c.setRequestProperty("Connection", "close")
            if (c.responseCode != 200) return ""
            val raw = c.inputStream
            val ins = if ("gzip".equals(c.getHeaderField("Content-Encoding"), true)) GZIPInputStream(raw) else raw
            return ins.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            return ""
        } finally {
            c?.disconnect()
        }
    }

    @JavascriptInterface fun httpGetNative(url: String?): String {
        if (url.isNullOrBlank()) return ""
        val out = java.util.concurrent.atomic.AtomicReference<String>("")
        val latch = java.util.concurrent.CountDownLatch(1)
        Thread {
            try { out.set(get(url)) } catch (e: Exception) {} finally { latch.countDown() }
        }.start()
        try { latch.await(6, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) {}
        return out.get() ?: ""
    }

    @JavascriptInterface fun fetchMsnWeather(lat: String?, lon: String?): String {
        val q = "ocid=weather-app-mobile&apiKey=OkWqHMuutahBXs3dBoygqCjgXRt6CV4i5V7SRQURrT&lat=" + lat + "&lon=" + lon + "&locale=zh-cn&units=C&days=10"
        val a = httpGetNative("https://assets.msn.cn/service/weatherfalcon/weather/overview?" + q)
        if (a.length >= 80) return a
        val b = httpGetNative("https://assets.msn.com/service/weatherfalcon/weather/overview?" + q)
        return if (b.isNotEmpty()) b else a
    }

    @JavascriptInterface fun getNativeLocation(): String {
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (pv in listOf("gps", "network", "passive")) {
                val l = try { lm.getLastKnownLocation(pv) } catch (e: Exception) { null } ?: continue
                if (best == null || l.time > best.time) best = l
            }
            val b = best ?: return ""
            if (System.currentTimeMillis() - b.time > 12L * 3600L * 1000L) return ""
            return b.latitude.toString() + "," + b.longitude + "," + b.accuracy
        } catch (e: Exception) {
            return ""
        }
    }

    @JavascriptInterface fun reverseGeoNative(lat: String?, lng: String?): String =
        get("https://restapi.amap.com/v3/geocode/regeo?key=e1a92305fb5f0bc2a6b4c87c21abf274&location=" + lng + "," + lat +
            "&extensions=all&radius=120&roadlevel=0&homeorcorp=1", 7000)

    @JavascriptInterface fun clearLocationCache() {}

    @JavascriptInterface fun openUrl(u: String?) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }

    @JavascriptInterface fun openNotificationListenerSettings() {
        try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }

    // 以下是原应用给桌面小部件缓存数据用的，这里不需要
    @JavascriptInterface fun requestNotificationPermission() {}
    @JavascriptInterface fun showNotification(a: String?, b: String?) {}
    @JavascriptInterface fun saveHours(a: String?) {}
    @JavascriptInterface fun saveLunar(a: String?, b: String?) {}
    @JavascriptInterface fun saveMetrics(a: String?, b: String?) {}
    @JavascriptInterface fun savePrecip(a: String?) {}
    @JavascriptInterface fun saveWeather(a: String?, b: String?, c: String?, d: String?, e: String?, f: String?) {}
    @JavascriptInterface fun saveWeek(a: String?) {}
    @JavascriptInterface fun saveWidgetStyle(a: String?) {}
    @JavascriptInterface fun saveWidgetTheme(a: String?, b: String?, c: String?) {}
}
