package com.pixel.desk

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * 通知使用权：
 * 1) 让桌面读取正在播放的音乐会话（音乐卡片）；
 * 2) 统计每个应用的未读通知数量，用于图标角标。只统计数量，不读取通知内容。
 */
class MediaListener : NotificationListenerService() {
    companion object {
        @Volatile var counts: Map<String, Int> = emptyMap()
        @Volatile var onChange: (() -> Unit)? = null
    }

    private fun recompute() {
        val m = HashMap<String, Int>()
        try {
            val list = activeNotifications
            if (list != null) for (sbn in list) {
                val n = sbn.notification ?: continue
                val skip = Notification.FLAG_ONGOING_EVENT or Notification.FLAG_FOREGROUND_SERVICE or Notification.FLAG_GROUP_SUMMARY
                if ((n.flags and skip) != 0) continue
                m[sbn.packageName] = (m[sbn.packageName] ?: 0) + 1
            }
        } catch (e: Exception) {}
        counts = m
        onChange?.invoke()
    }

    override fun onListenerConnected() { recompute() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { recompute() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { recompute() }
}
