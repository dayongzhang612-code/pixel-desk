package com.pixel.desk

import android.service.notification.NotificationListenerService

/** 只用来获得「通知使用权」，以便读取正在播放的音乐会话，不读取任何通知内容。 */
class MediaListener : NotificationListenerService()
