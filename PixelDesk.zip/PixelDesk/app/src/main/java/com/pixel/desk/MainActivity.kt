package com.pixel.desk

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.provider.CalendarContract
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.app.WallpaperManager
import android.graphics.Color
import android.os.Handler
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.IntentFilter
import android.view.inputmethod.EditorInfo
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.ClipData
import android.content.ClipboardManager
import android.content.res.Configuration
import android.content.res.Resources
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.icu.text.Transliterator
import android.net.Uri
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    class App(val label: String, val key: String, val icon: Drawable, val py: String, val ini: String) {
        val pkg get() = key.substringBefore('/')
    }

    private lateinit var sp: SharedPreferences
    private var all = listOf<App>()
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var pager: Pager
    private lateinit var pagerBox: LinearLayout
    private lateinit var dots: LinearLayout
    private var cur = 0
    private var widgetEdit = false
    private lateinit var negTitle: TextView
    private lateinit var glanceBox: LinearLayout
    private lateinit var negQuote: TextView
    private lateinit var negTime: TextView
    private lateinit var negWx: LinearLayout
    private var showingCrash = false
    private var dirty = true
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { dirty = true }
    }
    private lateinit var pillV: TextView
    private lateinit var glanceDate: TextView
    private lateinit var glanceWx: TextView
    private var dragApp: App? = null
    private var dragWhere = 1
    private var dragChanged = false
    private var dragMoved = false
    private var dragX0 = -1f
    private var dragY0 = -1f
    private var lastFlip = 0L
    private var pageCount = 1
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var dGrid: GridView
    private lateinit var search: EditText
    private lateinit var recent: LinearLayout
    private lateinit var gd: GestureDetector
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var negative: LinearLayout
    private var negativeOpen = false
    private val widgetHostId = 14001
    private val reqWidgetConfigure = 9101
    private val reqWidgetBind = 9102
    private var pendingWidgetId = -1
    private var drawerOpen = false
    private var menuShown = false
    private val tr by lazy { try { Transliterator.getInstance("Han-Latin;Latin-ASCII") } catch (e: Exception) { null } }

    private val layouts = listOf(4 to 5, 4 to 6, 5 to 5, 5 to 6)
    private val sizes = listOf(48, 56, 64, 72)
    private val docks = listOf(3, 4, 5)
    private val shapes = listOf("圆形", "圆角", "原生比例")
    private val themes = listOf("跟随系统", "深色", "浅色")
    private val cols get() = layouts[gi("layout", 0)].first
    private val rows get() = layouts[gi("layout", 0)].second
    private val dark get() = when (gi("theme", 0)) {
        1 -> true; 2 -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val tints = listOf("壁纸取色", "系统 Material You", "默认蓝")
    private val blurNames = listOf("关", "中", "强")
    private val blurDp = listOf(0, 24, 48)
    private var curBlur = 0f
    private var curScrim = 0f
    private var blurAnim: ValueAnimator? = null
    private val colorsListener = WallpaperManager.OnColorsChangedListener { _, _ -> refresh() }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.argb(Color.alpha(a), ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    private val seed: Int? get() {
        if (gi("tint", 0) != 0) return null
        return try {
            WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)?.primaryColor?.toArgb()
        } catch (e: Exception) { null }
    }

    private var accCache = 0
    private var accTime = 0L
    private val accent: Int get() {
        val n = System.currentTimeMillis()
        if (accCache == 0 || n - accTime > 3000L) { accCache = computeAccent(); accTime = n }
        return accCache
    }

    private fun computeAccent(): Int {
        val s = seed
        return when {
            s != null -> if (dark) mix(s or 0xFF000000.toInt(), Color.WHITE, 0.4f) else mix(s or 0xFF000000.toInt(), Color.BLACK, 0.1f)
            gi("tint", 0) != 2 && Build.VERSION.SDK_INT >= 31 -> try { getColor(android.R.color.system_accent1_200) } catch (e: Exception) { 0xFFB4C5FF.toInt() }
            else -> 0xFFB4C5FF.toInt()
        }
    }

    private fun applyBlur(px: Int) {
        if (Build.VERSION.SDK_INT >= 31) try {
            if (windowManager.isCrossWindowBlurEnabled) window.setBackgroundBlurRadius(px)
        } catch (e: Exception) {}
    }

    private fun animateBlur(open: Boolean) {
        val target = if (open) dp(blurDp[gi("blur", 1)]).toFloat() else 0f
        val scrimT = if (open) 0x66 else 0
        blurAnim?.cancel()
        val b0 = curBlur; val s0 = curScrim
        blurAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur(if (open) 320L else 260L)
            addUpdateListener {
                val f = it.animatedFraction
                curBlur = b0 + (target - b0) * f
                curScrim = s0 + (scrimT - s0) * f
                root.setBackgroundColor(Color.argb(curScrim.toInt(), 0, 0, 0))
                applyBlur(curBlur.toInt())
            }
            start()
        }
    }

    private fun list(k: String): MutableList<String> = try {
        (sp.getString(k, "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableList()
    } catch (e: ClassCastException) {
        sp.edit().remove(k).apply(); mutableListOf()
    }
    private fun save(k: String, l: List<String>) = sp.edit().putString(k, l.joinToString(",")).apply()
    private fun gi(k: String, d: Int): Int {
        return try {
            sp.getInt(k, d)
        } catch (e: ClassCastException) {
            val v = sp.getString(k, null)?.toIntOrNull()
            if (v != null) { sp.edit().putInt(k, v).apply(); v } else d
        } catch (e: Exception) { d }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); setStroke(dp(1), 0x33FFFFFF)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("pixel_desk", Context.MODE_PRIVATE)
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { sp.edit().putString("crash", Log.getStackTraceString(e).take(2500)).commit() } catch (t: Throwable) {}
            android.os.Process.killProcess(android.os.Process.myPid())
            System.exit(10)
        }
        val crash = sp.getString("crash", null)
        if (crash != null) {
            sp.edit().remove("crash").commit()
            showingCrash = true
            setContentView(ScrollView(this).apply {
                setBackgroundColor(Color.WHITE)
                addView(TextView(context).apply {
                    text = "上次崩溃信息（请截图发给开发者）：\n\n" + crash
                    setTextColor(Color.BLACK); textSize = 12f
                    setPadding(dp(16), dp(48), dp(16), dp(16)); setTextIsSelectable(true)
                })
            })
            return
        }
        applySystemBars()
        window.statusBarColor = 0; window.navigationBarColor = 0
        widgetHost = AppWidgetHost(this, widgetHostId)
        widgetHost.startListening()
        buildUi()
        try {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(pkgReceiver, f)
        } catch (e: Exception) {}
        try { WallpaperManager.getInstance(this).addOnColorsChangedListener(colorsListener, Handler(mainLooper)) } catch (e: Exception) {}
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (!drawerOpen && Math.abs(dx) > dp(90) && Math.abs(dx) > Math.abs(dy) * 1.35f && Math.abs(vx) > 700) {
                    if (dx > 0) openNegative(true) else openNegative(false)
                    return true
                }
                if (!drawerOpen && dy < -dp(80) && vy < -800 && gi("g_up", 0) == 0 && !negativeOpen) openDrawer(true)
                else if (drawerOpen && dy > dp(80) && vy > 800 && (dGrid.firstVisiblePosition == 0) &&
                    (dGrid.getChildAt(0)?.top ?: 0) >= 0) openDrawer(false)
                else if (!drawerOpen && dy > dp(80) && vy > 800 && Math.abs(dy) > Math.abs(e2.x - e1.x) * 1.5f && !negativeOpen) downGesture()
                return false
            }
            override fun onLongPress(e: MotionEvent) {
                root.postDelayed({ if (!menuShown && !drawerOpen && !negativeOpen) showSettings() }, 60)
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (onEmptyHome(e.rawX, e.rawY)) when (gi("g_dbl", 0)) {
                    1 -> lockScreen()
                    2 -> showSettings()
                }
                return false
            }
        })
    }

    private fun applySystemBars() {
        val base = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        val hide = if (sp.getBoolean("immersive", false))
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY else 0
        window.decorView.systemUiVisibility = base or hide
        if (::root.isInitialized) root.requestApplyInsets()
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !showingCrash) applySystemBars()
    }

    override fun onDestroy() {
        MediaListener.onChange = null
        try { widgetHost.stopListening() } catch (e: Exception) {}
        super.onDestroy()
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}
        try { WallpaperManager.getInstance(this).removeOnColorsChangedListener(colorsListener) } catch (e: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (showingCrash) return
        if (dirty || all.isEmpty()) load()
        MediaListener.onChange = { runOnUiThread { updateBadges() } }
        refresh()
        maybeLoadWeather()
        updateNegHeader()
        if (!sp.contains("hinted")) {
            sp.edit().putBoolean("hinted", true).apply()
            Toast.makeText(this, "上滑打开应用抽屉；长按图标可添加到桌面，长按空白处进入设置", Toast.LENGTH_LONG).show()
        }
    }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (showingCrash) return super.dispatchTouchEvent(ev)
        if (ev.action == MotionEvent.ACTION_DOWN) menuShown = false
        gd.onTouchEvent(ev); return super.dispatchTouchEvent(ev)
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (showingCrash) { finish(); return }
        if (drawerOpen) { openDrawer(false); return }
        if (negativeOpen) { openNegative(false); return }
    }
    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (showingCrash) return
        if (drawerOpen) openDrawer(false)
        else if (negativeOpen) openNegative(false)
        else if (cur != 0) { cur = 0; pager.smoothScrollTo(0, 0); drawDots() }
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setOnDragListener { _, ev -> onDrag(ev) }
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x40000000, 0x00000000, 0x00000000, 0x66000000))
        }
        pillV = TextView(this).apply {
            text = ""; setCompoundDrawables(GoogleG(dp(22)).also { it.setBounds(0, 0, dp(22), dp(22)) }, null, null, null); compoundDrawablePadding = dp(12); setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
            setCompoundDrawables(GoogleG(dp(22)).also { it.setBounds(0, 0, dp(22), dp(22)) }, null, PillIcons(dp(22)).also { it.setBounds(0, 0, (dp(22) * 2.7f).toInt(), dp(22)) }, null)
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(22), 0, dp(22), 0)
            background = glass(0x33FFFFFF, 28)
            setOnTouchListener { _, ev -> if (ev.action == MotionEvent.ACTION_DOWN) pillX = ev.x; false }
            setOnClickListener {
                when {
                    pillX > width - dp(62) -> lensSearch()
                    pillX > width - dp(104) -> voiceSearch()
                    else -> openDrawer(true)
                }
            }
        }
        glanceDate = TextView(this).apply {
            textSize = 30f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(6f, 0f, 2f, 0x99000000.toInt())
        }
        glanceWx = TextView(this).apply {
            textSize = 15f; setTextColor(0xE6FFFFFF.toInt()); setPadding(0, dp(2), 0, 0)
            setShadowLayer(6f, 0f, 2f, 0x99000000.toInt())
        }
        glanceBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(28), dp(24), dp(28), dp(6))
            addView(glanceDate); addView(glanceWx)
            setOnClickListener { onWeatherTap() }
        }
        home.addView(glanceBox, LinearLayout.LayoutParams(-1, -2))
        pagerBox = LinearLayout(this)
        pager = Pager(this).apply {
            addView(pagerBox, FrameLayout.LayoutParams(-2, -1))
            onPage = { cur = it; drawDots() }
        }
        home.addView(pager, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        home.addView(dots, LinearLayout.LayoutParams(-1, dp(16)))
        dock = LinearLayout(this).apply { gravity = Gravity.CENTER; minimumHeight = dp(80) }
        home.addView(dock, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(8), dp(16), dp(10)) })
        home.addView(pillV, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(dp(20), 0, dp(20), dp(14)) })
        root.addView(home, FrameLayout.LayoutParams(-1, -1))

        negative = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(24))
            visibility = View.GONE
            background = android.graphics.drawable.LayerDrawable(arrayOf(
                GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF090C12.toInt(), 0xFF141A26.toInt())),
                GradientDrawable().apply {
                    gradientType = GradientDrawable.RADIAL_GRADIENT; gradientRadius = dp(460).toFloat()
                    setGradientCenter(0.12f, 0.04f); colors = intArrayOf((accent and 0x00FFFFFF) or 0x44000000, 0x00000000)
                }))
        }
        root.addView(negative, FrameLayout.LayoutParams(-1, -1))
        buildNegative()

        drawer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true }
        drawer.addView(View(this).apply {
            background = GradientDrawable().apply { setColor(0x66808080); cornerRadius = dp(2).toFloat() }
        }, LinearLayout.LayoutParams(dp(36), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; setMargins(0, dp(6), 0, dp(10)) })
        search = EditText(this).apply {
            hint = "搜索应用 / 拼音 / 首字母"; setSingleLine(); setPadding(dp(22), 0, dp(22), 0)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> drawerApps.firstOrNull()?.let { launch(it) }; true }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { refreshDrawer() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        drawer.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(dp(8), dp(4), dp(8), dp(8)) })
        recent = LinearLayout(this)
        recentLabel = TextView(this).apply { text = "最近使用"; textSize = 12f; setPadding(dp(14), dp(2), 0, dp(2)); visibility = View.GONE }
        drawer.addView(recentLabel)
        drawer.addView(recent, LinearLayout.LayoutParams(-1, -2))
        dGrid = GridView(this).apply {
            setSelector(pressSel(true)); isFastScrollEnabled = false
            setOnItemClickListener { _, v, p, _ -> launch((adapter as Ad).data[p], v) }
            setOnItemLongClickListener { _, v, p, _ -> menuShown = true; startDrag((adapter as Ad).data[p], 0, v); true }
        }
        val gridFrame = FrameLayout(this)
        gridFrame.addView(dGrid, FrameLayout.LayoutParams(-1, -1))
        letterBar = LetterBar(this)
        letterBubble = TextView(this).apply {
            textSize = 38f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); visibility = View.GONE
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply { setColor(0xCC20262F.toInt()); cornerRadius = dp(22).toFloat() }
        }
        letterBar.onPick = { ch, down ->
            if (down) {
                letterIndex[ch]?.let { dGrid.setSelection(it) }
                letterBubble.text = ch.toString(); letterBubble.visibility = View.VISIBLE
            } else letterBubble.visibility = View.GONE
        }
        gridFrame.addView(letterBar, FrameLayout.LayoutParams(dp(24), -1, Gravity.END).apply { topMargin = dp(6); bottomMargin = dp(6) })
        gridFrame.addView(letterBubble, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
        drawer.addView(gridFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        root.post { drawer.translationY = root.height.toFloat() }
        root.setOnApplyWindowInsetsListener { _, i ->
            val top = if (sp.getBoolean("immersive", false)) 0 else i.systemWindowInsetTop
            val cut = if (Build.VERSION.SDK_INT >= 28) (i.displayCutout?.safeInsetTop ?: 0) else 0
            val cam = if (sp.getBoolean("immersive", false)) maxOf(cut, dp(44)) else 0
            glanceBox.setPadding(dp(28), cam + dp(14), dp(28), dp(6))
            home.setPadding(0, top, 0, i.systemWindowInsetBottom)
            negative.setPadding(dp(18), top + cam + dp(12), dp(18), i.systemWindowInsetBottom + dp(24))
            drawer.setPadding(dp(12), top + cam + dp(12), dp(12), i.systemWindowInsetBottom); i
        }
        setContentView(root)
    }

    private fun openNegative(open: Boolean) {
        if (drawerOpen) return
        negativeOpen = open
        if (!open) widgetEdit = false
        negative.visibility = if (open) View.VISIBLE else View.GONE
        if (open) {
            cardsAnimate = true; negative.alpha = 0f; negative.scaleX = 1.04f; negative.scaleY = 1.04f
            negative.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(dur(260)).setInterpolator(DecelerateInterpolator()).start()
            refreshNegative()
        }
    }

    private fun buildNegative() {
        negative.removeAllViews()
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, dp(4), dp(8)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        negTime = android.widget.TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            textSize = 56f; includeFontPadding = false; setTextColor(BEIGE)
            setTypeface(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL))
        }
        top.addView(negTime, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(ImageView(this).apply {
            setImageDrawable(GoogleG(dp(24)).also { it.setBounds(0, 0, dp(24), dp(24)) })
            scaleType = ImageView.ScaleType.CENTER
            background = GradientDrawable().apply { setColor(BEIGE); cornerRadius = dp(22).toFloat() }
            setOnClickListener { openGoogle() }
            setOnLongClickListener { showWidgetPicker(); true }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        hero.addView(top)
        negTitle = TextView(this).apply {
            textSize = 22f; setTextColor(BEIGE); setPadding(0, dp(6), 0, 0)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        hero.addView(negTitle)
        negQuote = TextView(this).apply {
            textSize = 13f; maxLines = 3; setTextColor(BEIGE_SUB); setPadding(0, dp(4), 0, 0)
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.iciba.com/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
            }
        }
        hero.addView(negQuote)
        hero.addView(View(this).apply { setBackgroundColor(0x22FFFFFF) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(0, dp(14), 0, dp(14)) })
        negWx = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hero.addView(negWx, LinearLayout.LayoutParams(-1, -2))
        negative.addView(hero, LinearLayout.LayoutParams(-1, -2))
        negative.addView(View(this), LinearLayout.LayoutParams(-1, dp(4)))
        val sc = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sc.addView(box, FrameLayout.LayoutParams(-1, -2))
        negative.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        refreshNegative()
    }

    private var pillX = 0f

    private fun voiceSearch() {
        try { startActivity(Intent(android.speech.RecognizerIntent.ACTION_WEB_SEARCH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { openGoogle() }
    }

    private fun lensSearch() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("googleapp://lens")).setPackage("com.google.android.googlequicksearchbox")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { openGoogle() }
    }

    private fun openGoogle() {
        val i = packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "无法打开谷歌", Toast.LENGTH_SHORT).show() }
    }

    private fun renderWeatherHero() {
        if (!::negWx.isInitialized) return
        negWx.removeAllViews()
        negWx.setOnClickListener { onWeatherTap() }
        val p = (sp.getString("wx", null) ?: "").split("|")
        if (p.size < 9) {
            negWx.addView(TextView(this).apply {
                text = if (hasLoc()) "正在获取天气…" else "点击授权定位，显示当地天气"
                textSize = 14f; setTextColor(BEIGE_SUB)
            })
            return
        }
        wxIcon(p[2], dp(56))?.let { ic ->
            negWx.addView(ImageView(this).apply { setImageDrawable(ic) },
                LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(12) })
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { gravity = Gravity.BOTTOM }
        row.addView(TextView(this).apply {
            text = p[1] + "°"; textSize = 34f; includeFontPadding = false; setTextColor(BEIGE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        row.addView(TextView(this).apply { text = "  " + p[2]; textSize = 16f; setTextColor(BEIGE); setPadding(0, 0, 0, dp(3)) })
        left.addView(row)
        left.addView(TextView(this).apply {
            text = p[0] + "  ·  最高" + p[6] + "°  最低" + p[7] + "°"; textSize = 13f; setTextColor(BEIGE_SUB); setPadding(0, dp(4), 0, 0)
        })
        negWx.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        negWx.addView(TextView(this).apply {
            text = "体感 " + p[3] + "°\n湿度 " + p[4] + "%" + (if (p[5].isNotBlank()) "\n空气 " + p[5] else "")
            textSize = 13f; setTextColor(BEIGE_SUB); gravity = Gravity.END
        })
    }

    private fun refreshNegative() {
        if (!::negative.isInitialized) return
        updateNegHeader()
        val sc = negative.getChildAt(2) as? ScrollView ?: return
        val box = sc.getChildAt(0) as? LinearLayout ?: return
        box.removeAllViews()
        cardsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(cardsBox, LinearLayout.LayoutParams(-1, -2))
        renderCards()
        maybeLoadWeather()
        maybeLoadWeibo()
        val ids = list("widgets").mapNotNull { it.toIntOrNull() }
        if (ids.isEmpty()) widgetEdit = false else addWidgetHeader(box)
        if (ids.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "\n\n      ＋\n\n添加你常用的小部件\n天气 · 日历 · 音乐 · 电池 · 待办 · 时钟"
                gravity = Gravity.CENTER; textSize = 16f
                setTextColor(BEIGE)
                background = glass(0x1AFFFFFF, 12)
                setOnClickListener { showWidgetPicker() }
            }, LinearLayout.LayoutParams(-1, dp(250)).apply { setMargins(0, dp(8), 0, dp(10)) })
        } else {
            ids.forEach { id ->
                try {
                    val v = widgetHost.createView(this, id, AppWidgetManager.getInstance(this).getAppWidgetInfo(id))
                    v.setPadding(0, 0, 0, 0)
                    v.outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat()) }
                    }
                    v.clipToOutline = true
                    v.post {
                        try {
                            val w = (v.width / resources.displayMetrics.density).toInt()
                            v.updateAppWidgetSize(null, w, 40, w, 600)
                        } catch (e: Exception) {}
                    }
                    val frame = LongFrame(this) { if (!widgetEdit) { widgetEdit = true; refreshNegative() } }
                    frame.addView(v, FrameLayout.LayoutParams(-1, -2))
                    if (widgetEdit) {
                        frame.addView(View(this).apply {
                            isClickable = true
                            background = GradientDrawable().apply { setColor(0x66000000); cornerRadius = dp(12).toFloat() }
                        }, FrameLayout.LayoutParams(-1, -1))
                        frame.addView(roundBtn("✕", 0xFFB3402E.toInt()) { confirmRemove(id) },
                            FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END or Gravity.TOP).apply { setMargins(0, dp(8), dp(8), 0) })
                        if (ids.size > 1) {
                            frame.addView(roundBtn("↑", OLIVE_L) { moveWidget(id, -1) },
                                FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END or Gravity.BOTTOM).apply { setMargins(0, 0, dp(52), dp(8)) })
                            frame.addView(roundBtn("↓", OLIVE_L) { moveWidget(id, 1) },
                                FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END or Gravity.BOTTOM).apply { setMargins(0, 0, dp(8), dp(8)) })
                        }
                    }
                    box.addView(frame, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) })
                } catch (e: Exception) { removeWidget(id) }
            }
        }
    }

    private fun showWidgetPicker() {
        val providers = AppWidgetManager.getInstance(this).installedProviders.sortedBy { it.label?.toString()?.lowercase() ?: "" }
        if (providers.isEmpty()) { Toast.makeText(this, "没有可用的小部件", Toast.LENGTH_SHORT).show(); return }
        val labels = providers.map { "${it.loadLabel(packageManager)}  ·  ${it.provider.packageName}" }.toTypedArray()
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("添加小部件").setItems(labels) { _, which -> addWidget(providers[which]) }
            .setNegativeButton("取消", null).show()
    }

    private fun addWidget(info: AppWidgetProviderInfo) {
        val manager = AppWidgetManager.getInstance(this)
        val id = widgetHost.allocateAppWidgetId()
        if (!manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            pendingWidgetId = id
            try {
                startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                }, reqWidgetBind)
            } catch (e: Exception) { widgetHost.deleteAppWidgetId(id); pendingWidgetId = -1; Toast.makeText(this, "此小部件需要系统授权", Toast.LENGTH_SHORT).show() }
            return
        }
        finishAddWidget(id, info)
    }

    private fun finishAddWidget(id: Int, info: AppWidgetProviderInfo) {
        pendingWidgetId = id
        if (info.configure != null) {
            try { startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply { component = info.configure; putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id) }, reqWidgetConfigure) } catch (e: Exception) { saveWidget(id); pendingWidgetId = -1 }
        } else { saveWidget(id); pendingWidgetId = -1 }
    }

    private fun saveWidget(id: Int) {
        val l = list("widgets"); if (id !in l.mapNotNull { it.toIntOrNull() }) { l.add(id.toString()); save("widgets", l) }
        refreshNegative()
    }

    private inner class LongFrame(c: Context, val onLong: () -> Unit) : FrameLayout(c) {
        private val det = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) { onLong() }
        })
        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            det.onTouchEvent(ev)
            return false
        }
    }

    private fun roundBtn(label: String, color: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(18).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun addWidgetHeader(box: LinearLayout) {
        val hdr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(10), dp(4), dp(2)) }
        hdr.addView(TextView(this).apply {
            text = if (widgetEdit) "编辑小部件：点 ✕ 移除，↑ ↓ 调整顺序" else "小部件"
            textSize = 13f; setTextColor(BEIGE_SUB)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        hdr.addView(TextView(this).apply {
            text = if (widgetEdit) "完成" else "编辑"; textSize = 13f; setTextColor(BEIGE)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = GradientDrawable().apply { setColor(0x26FFFFFF); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0x22FFFFFF) }
            setOnClickListener { widgetEdit = !widgetEdit; refreshNegative() }
        })
        box.addView(hdr)
    }

    private fun confirmRemove(id: Int) {
        AlertDialog.Builder(this, R.style.PixelDialog).setMessage("从负一屏移除这个小部件？")
            .setPositiveButton("移除") { _, _ -> removeWidget(id) }
            .setNegativeButton("取消", null).show()
    }

    private fun moveWidget(id: Int, d: Int) {
        val l = list("widgets"); val i = l.indexOf(id.toString()); val j = i + d
        if (i < 0 || j < 0 || j >= l.size) return
        val t = l[i]; l[i] = l[j]; l[j] = t
        save("widgets", l); refreshNegative()
    }

    private fun removeWidget(id: Int) {
        try { widgetHost.deleteAppWidgetId(id) } catch (e: Exception) {}
        save("widgets", list("widgets").filter { it != id.toString() }); refreshNegative()
    }

    // ---------- 应用锁（使用系统锁屏验证） ----------
    private val reqAuth = 9301
    private var authApp: App? = null

    private fun toggleLock(a: App) {
        val l = list("locked")
        if (a.key in l) l.remove(a.key) else l.add(a.key)
        save("locked", l)
        Toast.makeText(this, if (a.key in l) "已加应用锁" else "已解除应用锁", Toast.LENGTH_SHORT).show()
    }

    private fun requireAuth(a: App) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) {
            Toast.makeText(this, "请先在系统设置里设置锁屏密码或指纹，应用锁才能生效", Toast.LENGTH_LONG).show()
            return
        }
        @Suppress("DEPRECATION")
        val i = km.createConfirmDeviceCredentialIntent("解锁 " + a.label, "验证后打开应用")
        if (i == null) { launchNow(a); return }
        authApp = a
        try { startActivityForResult(i, reqAuth) } catch (e: Exception) { authApp = null }
    }

    // ---------- 负一屏内置卡片 ----------
    private lateinit var cardsBox: LinearLayout
    private val reqCal = 9302
    private val OLIVE: Int get() = accent                 // 现在表示“强调色”（取自壁纸）
    private val OLIVE_L = 0xFF2C3342.toInt()
    private val BEIGE = 0xFFF3F5F9.toInt()                // 浅色文字 / 浅色按钮底
    private val BEIGE_SUB = 0x99F3F5F9.toInt()
    private val INK = 0xFFF3F5F9.toInt()                  // 卡片主文字
    private val INK_SUB = 0x99F3F5F9.toInt()              // 卡片次文字
    private val ON_ACCENT = 0xFF10131A.toInt()            // 强调色底上的文字
    private val textMain get() = INK
    private val textSub get() = INK_SUB

    private fun card(title: String, body: View, olive: Boolean = false, pad: Boolean = true): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        if (pad) setPadding(dp(16), dp(14), dp(16), dp(14))
        else {
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(12).toFloat()) }
            }
            clipToOutline = true
        }
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x2AFFFFFF, 0x12FFFFFF)).apply { cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0x26FFFFFF) }
        if (title.isNotEmpty()) addView(TextView(context).apply { text = title; textSize = 12f; letterSpacing = 0.08f; setTextColor(if (olive) BEIGE_SUB else OLIVE) })
        addView(body)
    }

    private fun greeting(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..8 -> "早上好"
            in 9..11 -> "上午好"
            in 12..13 -> "中午好"
            in 14..17 -> "下午好"
            in 18..23 -> "晚上好"
            else -> "夜深了"
        }
    }

    private val quotes = listOf(
        "学而不思则罔，思而不学则殆。" to "《论语》",
        "三人行，必有我师焉。" to "《论语》",
        "己所不欲，勿施于人。" to "《论语》",
        "逝者如斯夫，不舍昼夜。" to "《论语》",
        "君子坦荡荡，小人长戚戚。" to "《论语》",
        "工欲善其事，必先利其器。" to "《论语》",
        "岁寒，然后知松柏之后凋也。" to "《论语》",
        "温故而知新，可以为师矣。" to "《论语》",
        "知之者不如好之者，好之者不如乐之者。" to "《论语》",
        "千里之行，始于足下。" to "《老子》",
        "上善若水，水善利万物而不争。" to "《老子》",
        "知人者智，自知者明。" to "《老子》",
        "吾生也有涯，而知也无涯。" to "《庄子》",
        "天行健，君子以自强不息。" to "《周易》",
        "地势坤，君子以厚德载物。" to "《周易》",
        "生于忧患，死于安乐。" to "《孟子》",
        "天时不如地利，地利不如人和。" to "《孟子》",
        "玉不琢，不成器；人不学，不知道。" to "《礼记》",
        "凡事预则立，不预则废。" to "《礼记》",
        "博学之，审问之，慎思之，明辨之，笃行之。" to "《礼记》",
        "不积跬步，无以至千里。" to "《荀子》",
        "锲而不舍，金石可镂。" to "《荀子》",
        "志不强者智不达。" to "《墨子》",
        "少壮不努力，老大徒伤悲。" to "《长歌行》",
        "非淡泊无以明志，非宁静无以致远。" to "诸葛亮《诫子书》",
        "勿以恶小而为之，勿以善小而不为。" to "刘备",
        "路漫漫其修远兮，吾将上下而求索。" to "屈原《离骚》",
        "长风破浪会有时，直挂云帆济沧海。" to "李白《行路难》",
        "天生我材必有用，千金散尽还复来。" to "李白《将进酒》",
        "会当凌绝顶，一览众山小。" to "杜甫《望岳》",
        "读书破万卷，下笔如有神。" to "杜甫",
        "海内存知己，天涯若比邻。" to "王勃",
        "莫愁前路无知己，天下谁人不识君。" to "高适",
        "沉舟侧畔千帆过，病树前头万木春。" to "刘禹锡",
        "业精于勤，荒于嬉；行成于思，毁于随。" to "韩愈《进学解》",
        "不畏浮云遮望眼，自缘身在最高层。" to "王安石《登飞来峰》",
        "古之立大事者，不惟有超世之才，亦必有坚忍不拔之志。" to "苏轼《晁错论》",
        "山重水复疑无路，柳暗花明又一村。" to "陆游《游山西村》",
        "纸上得来终觉浅，绝知此事要躬行。" to "陆游",
        "先天下之忧而忧，后天下之乐而乐。" to "范仲淹《岳阳楼记》",
        "莫等闲，白了少年头，空悲切。" to "岳飞《满江红》",
        "人生自古谁无死，留取丹心照汗青。" to "文天祥《过零丁洋》",
        "千磨万击还坚劲，任尔东西南北风。" to "郑燮《竹石》",
        "落红不是无情物，化作春泥更护花。" to "龚自珍",
        "海纳百川，有容乃大。" to "林则徐",
        "路遥知马力，日久见人心。" to "俗语",
    )

    private fun localQuote(): String {
        val c = java.util.Calendar.getInstance()
        val i = (c.get(java.util.Calendar.YEAR) * 366 + c.get(java.util.Calendar.DAY_OF_YEAR)) % quotes.size
        return "「" + quotes[i].first + "」—— " + quotes[i].second
    }

    private fun reminder(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..8 -> "记得吃早餐"
            in 9..11 -> "专注一会儿"
            in 12..13 -> "该吃午饭了"
            in 14..17 -> "起来活动一下"
            in 18..21 -> "辛苦了，放松一下"
            in 22..23 -> "早点休息"
            else -> "该睡觉了"
        }
    }

    // ---------- 每日一句：金山词霸 ----------
    private var dqFetching = false
    private var dqLastTry = 0L

    private fun dailyQuote(): String {
        val today = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
        val en = sp.getString("dq_en", null) ?: ""
        val cn = sp.getString("dq_cn", null) ?: ""
        if (sp.getString("dq_date", "") != today) loadDaily(today)
        if (en.isBlank()) return localQuote()
        return if (cn.isBlank()) en else cn + "\n" + en
    }

    private fun loadDaily(today: String) {
        val now = System.currentTimeMillis()
        if (dqFetching || now - dqLastTry < 10 * 60 * 1000L) return
        dqFetching = true; dqLastTry = now
        Thread {
            try {
                val j = org.json.JSONObject(http("https://open.iciba.com/dsapi/"))
                val en = j.optString("content", "").trim()
                val cn = j.optString("note", "").trim()
                if (en.isNotEmpty()) sp.edit().putString("dq_en", en).putString("dq_cn", cn).putString("dq_date", today).apply()
            } catch (e: Exception) {}
            runOnUiThread { dqFetching = false; updateNegHeader() }
        }.start()
    }

    private fun updateNegHeader() {
        if (!::negTitle.isInitialized) return
        val g = greeting()
        val sb = android.text.SpannableStringBuilder(g + "   " + reminder())
        val flag = android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        sb.setSpan(android.text.style.RelativeSizeSpan(0.62f), g.length, sb.length, flag)
        sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.NORMAL), g.length, sb.length, flag)
        sb.setSpan(android.text.style.ForegroundColorSpan(BEIGE_SUB), g.length, sb.length, flag)
        negTitle.text = sb
        val dq = dailyQuote()
        val nl = dq.indexOf('\n')
        if (nl > 0) {
            val sq = android.text.SpannableStringBuilder(dq)
            val fl = android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            sq.setSpan(android.text.style.RelativeSizeSpan(1.08f), 0, nl, fl)
            sq.setSpan(android.text.style.ForegroundColorSpan(BEIGE), 0, nl, fl)
            sq.setSpan(android.text.style.RelativeSizeSpan(0.92f), nl + 1, dq.length, fl)
            negQuote.text = sq
        } else negQuote.text = dq
    }

    private var cardsAnimate = false
    private lateinit var letterBar: LetterBar
    private lateinit var letterBubble: TextView
    private var letterIndex: Map<Char, Int> = emptyMap()
    private lateinit var recentLabel: TextView

    private fun renderCards() {
        if (!::cardsBox.isInitialized) return
        cardsBox.removeAllViews()
        fun lp() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }
        renderWeatherHero()
        fun on(i: Int) = sp.getBoolean("card_" + i, true)
        fun safe(block: () -> Unit) { try { block() } catch (e: Exception) {} }
        if (on(0)) safe { cardsBox.addView(card("日历", calendarBody()).apply { setOnClickListener { askCalendar() } }, lp()) }
        if (on(1)) safe { cardsBox.addView(card("", shortcutBody()), lp()) }
        if (on(2)) safe { cardsBox.addView(card("", musicBody(), false, false), lp()); startMusicTicker() } else mVinyl = null
        if (on(3)) safe { cardsBox.addView(card("", weiboBody()), lp()) }
        if (on(4)) safe { cardsBox.addView(card("电池", batteryBody()), lp()) }
        if (on(5)) safe { cardsBox.addView(card("待办", todoBody()), lp()) }
        if (cardsAnimate) {
            cardsAnimate = false
            for (i in 0 until cardsBox.childCount) {
                val c = cardsBox.getChildAt(i)
                c.alpha = 0f; c.translationY = dp(18).toFloat()
                c.animate().alpha(1f).translationY(0f).setStartDelay(dur(i * 55L)).setDuration(dur(260))
                    .setInterpolator(DecelerateInterpolator()).start()
            }
        }
    }

    private val cardNames = arrayOf("日历", "快捷方式", "音乐", "微博热搜", "电池", "待办")

    private fun cardsManager() {
        val checked = BooleanArray(cardNames.size) { sp.getBoolean("card_" + it, true) }
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("负一屏卡片")
            .setMultiChoiceItems(cardNames, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("完成") { _, _ ->
                val e = sp.edit()
                for (i in cardNames.indices) e.putBoolean("card_" + i, checked[i])
                e.apply(); renderCards()
            }
            .setNegativeButton("取消", null).show()
    }

    private fun askCalendar() {
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), reqCal)
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(rc, perms, results)
        if (rc == reqCal) renderCards()
        if (rc == reqLoc) { renderCards(); maybeLoadWeather() }
    }

    private fun lunarText(d: java.util.Date): String = try {
        android.icu.text.SimpleDateFormat("U年MMMMd", android.icu.util.ULocale("zh_CN@calendar=chinese")).format(d)
    } catch (e: Exception) { "" }

    private val lunarDays = listOf("初一","初二","初三","初四","初五","初六","初七","初八","初九","初十","十一","十二","十三","十四","十五","十六","十七","十八","十九","二十","廿一","廿二","廿三","廿四","廿五","廿六","廿七","廿八","廿九","三十")
    private val lunarMonths = listOf("正月","二月","三月","四月","五月","六月","七月","八月","九月","十月","冬月","腊月")
    private val solarFest = mapOf(101 to "元旦", 214 to "情人", 308 to "妇女", 312 to "植树", 501 to "劳动", 504 to "青年", 601 to "儿童",
        701 to "建党", 801 to "建军", 910 to "教师", 1001 to "国庆", 1225 to "圣诞")
    private val lunarFest = mapOf(1 * 100 + 1 to "春节", 1 * 100 + 15 to "元宵", 2 * 100 + 2 to "龙抬头", 5 * 100 + 5 to "端午", 7 * 100 + 7 to "七夕",
        7 * 100 + 15 to "中元", 8 * 100 + 15 to "中秋", 9 * 100 + 9 to "重阳", 12 * 100 + 8 to "腊八", 12 * 100 + 23 to "小年")
    private val termNames = listOf("小寒","大寒","立春","雨水","惊蛰","春分","清明","谷雨","立夏","小满","芒种","夏至","小暑","大暑","立秋","处暑","白露","秋分","寒露","霜降","立冬","小雪","大雪","冬至")
    private val termC = doubleArrayOf(5.4055, 20.12, 3.87, 18.73, 5.63, 20.646, 4.81, 20.1, 5.52, 21.04, 5.678, 21.37, 7.108, 22.83, 7.5, 23.13, 7.646, 23.042, 8.318, 23.438, 7.438, 22.36, 7.18, 21.94)
    private val termMonth = intArrayOf(1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12)

    private fun jieqi(y: Int, m: Int, d: Int): String? {
        val yy = y % 100
        for (k in termNames.indices) {
            if (termMonth[k] != m) continue
            val l = if (k < 4) (yy - 1) / 4 else yy / 4
            if (Math.floor(yy * 0.2422 + termC[k]).toInt() - l == d) return termNames[k]
        }
        return null
    }

    private fun lunarOf(cal: java.util.Calendar): Triple<Int, Int, Boolean> {
        val cc = android.icu.util.ChineseCalendar(cal.time)
        return Triple(cc.get(android.icu.util.Calendar.MONTH) + 1, cc.get(android.icu.util.Calendar.DAY_OF_MONTH),
            cc.get(android.icu.util.Calendar.IS_LEAP_MONTH) == 1)
    }

    // 第二行文字：节日 / 节气 优先，其次农历（初一显示月份）。第二个值表示是否高亮
    private fun subLine(cal: java.util.Calendar): Pair<String, Boolean> {
        try {
            val m = cal.get(java.util.Calendar.MONTH) + 1; val d = cal.get(java.util.Calendar.DAY_OF_MONTH)
            solarFest[m * 100 + d]?.let { return it to true }
            val (lm, ld, leap) = lunarOf(cal)
            if (!leap) {
                lunarFest[lm * 100 + ld]?.let { return it to true }
                if (lm == 12) {
                    val t = cal.clone() as java.util.Calendar; t.add(java.util.Calendar.DAY_OF_MONTH, 1)
                    if (lunarOf(t).let { it.first == 1 && it.second == 1 }) return "除夕" to true
                }
            }
            jieqi(cal.get(java.util.Calendar.YEAR), m, d)?.let { return it to true }
            return (if (ld == 1) (if (leap) "闰" else "") + lunarMonths[lm - 1] else lunarDays[ld - 1]) to false
        } catch (e: Exception) { return "" to false }
    }

    private val yiPool = listOf("会亲友 进人口 学习\n起基 定磉 开市", "开市 交易 立券\n挂匾 开光 出行", "祈福 求医 针灸\n结网 畋猎 取渔",
        "祈福 求嗣 纳财\n入宅 安床 嫁娶", "祭祀 沐浴 扫舍\n捕捉 畋猎 取渔", "订盟 纳采 冠笄\n裁衣 合帐 安机械", "赴任 出行 移徙\n分居 开市 立券")
    private val jiPool = listOf("作灶 行丧 理发\n乘船 嫁娶 安葬", "修造 动土 竖柱\n上梁 开仓 出货财", "动土 破土 开仓\n词讼 远行 入宅", "安葬 行丧 作梁\n造桥 开池 栽种")

    private fun yiJi(): Pair<String, String> {
        val n = java.time.LocalDate.now().toEpochDay()
        return yiPool[((n + 6) % 7).toInt()] to jiPool[((n + 2) % 4).toInt()]
    }

    private fun monthGrid(): View {
        val c = java.util.Calendar.getInstance()
        val today = c.get(java.util.Calendar.DAY_OF_MONTH)
        c.set(java.util.Calendar.DAY_OF_MONTH, 1)
        val first = c.get(java.util.Calendar.DAY_OF_WEEK) - 1
        val days = c.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this)
        for (t in listOf("日", "一", "二", "三", "四", "五", "六")) head.addView(TextView(this).apply {
            text = t; textSize = 11f; gravity = Gravity.CENTER; setTextColor(INK_SUB)
        }, LinearLayout.LayoutParams(0, dp(22), 1f))
        box.addView(head)
        var d = 1
        val rowsN = (first + days + 6) / 7
        for (r in 0 until rowsN) {
            val row = LinearLayout(this)
            for (k in 0 until 7) {
                val idx = r * 7 + k
                val cellBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                if (idx >= first && d <= days) {
                    val cc = c.clone() as java.util.Calendar; cc.set(java.util.Calendar.DAY_OF_MONTH, d)
                    val (sub, hot) = subLine(cc)
                    val isToday = d == today
                    cellBox.addView(TextView(this).apply {
                        text = d.toString(); textSize = 14f; gravity = Gravity.CENTER
                        setTextColor(if (isToday) ON_ACCENT else INK)
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                    })
                    cellBox.addView(TextView(this).apply {
                        text = sub; textSize = 8.5f; gravity = Gravity.CENTER; maxLines = 1
                        setTextColor(if (isToday) ON_ACCENT else if (hot) OLIVE else INK_SUB)
                        if (hot) setTypeface(typeface, android.graphics.Typeface.BOLD)
                    })
                    if (isToday) cellBox.background = GradientDrawable().apply { setColor(OLIVE); cornerRadius = dp(10).toFloat() }
                    d++
                }
                row.addView(cellBox, LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
            }
            box.addView(row)
        }
        return box
    }

    private fun badge(t: String, color: Int): TextView = TextView(this).apply {
        text = t; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(color); shape = GradientDrawable.OVAL }
    }

    private fun calendarBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val now = java.util.Date()
        val top = LinearLayout(this)
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(TextView(this).apply {
            text = java.text.SimpleDateFormat("M月d日", java.util.Locale.CHINA).format(now)
            textSize = 28f; setTextColor(textMain); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        left.addView(TextView(this).apply {
            text = java.text.SimpleDateFormat("EEEE", java.util.Locale.CHINA).format(now)
            textSize = 15f; setTextColor(textSub)
        })
        val lunar = lunarText(now)
        if (lunar.isNotEmpty()) left.addView(TextView(this).apply { text = lunar; textSize = 13f; setTextColor(textSub); setPadding(0, dp(2), 0, 0) })
        val (yi, ji) = yiJi()
        for ((lab, col, txt) in listOf(Triple("宜", 0xFFC9951B.toInt(), yi), Triple("忌", 0xFFB3402E.toInt(), ji))) {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
            r.addView(badge(lab, col), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(6) })
            r.addView(TextView(this).apply { text = txt; textSize = 12f; setTextColor(INK) })
            left.addView(r)
        }
        top.addView(left, LinearLayout.LayoutParams(0, -2, 5f))
        top.addView(monthGrid(), LinearLayout.LayoutParams(0, -2, 6f))
        box.addView(top)
        box.addView(View(this).apply { setBackgroundColor(0x22000000) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(0, dp(10), 0, dp(6)) })
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            box.addView(TextView(this).apply { text = "点击卡片授权，显示近期日程"; textSize = 13f; setTextColor(textSub) })
            return box
        }
        try {
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, now.time); ContentUris.appendId(b, now.time + 3L * 86400000L)
            contentResolver.query(b.build(), arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
                null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
                val f = java.text.SimpleDateFormat("M/d HH:mm", java.util.Locale.CHINA)
                var n = 0
                while (c.moveToNext() && n < 3) {
                    val line = f.format(java.util.Date(c.getLong(1))) + "  " + (c.getString(0) ?: "（无标题）")
                    box.addView(TextView(this).apply { text = line; textSize = 14f; setTextColor(textMain); setPadding(0, dp(4), 0, 0) })
                    n++
                }
                if (n == 0) box.addView(TextView(this).apply { text = "近 3 天没有日程"; textSize = 13f; setTextColor(textSub) })
            }
        } catch (e: Exception) {}
        return box
    }

    // ---------- 微博热搜（接口取自用户提供的天气应用） ----------
    private var wbFetching = false

    private fun weiboLogo(): View = ImageView(this).apply {
        val id = resources.getIdentifier("weibo_logo", "drawable", packageName)
        if (id != 0) setImageResource(id)
        scaleType = ImageView.ScaleType.FIT_CENTER
    }

    private fun fmtHeat(n: Long): String =
        if (n >= 10000) String.format(java.util.Locale.CHINA, "%.1f万", n / 10000.0) else n.toString()

    private fun maybeLoadWeibo() {
        if (System.currentTimeMillis() - sp.getLong("wb_t", 0L) > 5 * 60 * 1000L) loadWeibo()
    }

    private fun loadWeibo() {
        if (wbFetching) return
        wbFetching = true
        Thread {
            try {
                val c = java.net.URL("https://weibo.com/ajax/side/hotSearch").openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 10000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
                c.setRequestProperty("Referer", "https://weibo.com")
                c.setRequestProperty("Accept", "application/json, text/plain, */*")
                c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9")
                val txt = try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
                val arr = org.json.JSONObject(txt).getJSONObject("data").getJSONArray("realtime")
                val sb = StringBuilder()
                for (i in 0 until minOf(arr.length(), 12)) {
                    val o = arr.getJSONObject(i)
                    val w = o.optString("word", o.optString("note", "")).replace("\n", " ").replace("\t", " ")
                    if (w.isBlank()) continue
                    val num = o.optLong("num", o.optLong("raw_hot", 0L))
                    val tag = o.optString("label_name", "").replace("\n", " ").replace("\t", " ")
                    sb.append(w).append('\t').append(if (num > 0) fmtHeat(num) else "").append('\t').append(tag).append('\n')
                }
                if (sb.isNotEmpty()) sp.edit().putString("wb", sb.toString()).putLong("wb_t", System.currentTimeMillis()).apply()
            } catch (e: Exception) {}
            runOnUiThread { wbFetching = false; if (negativeOpen) renderCards() }
        }.start()
    }

    private fun openWeibo(word: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://m.weibo.cn/search?containerid=100103type%3D1%26q%3D" +
                java.net.URLEncoder.encode(word, "UTF-8"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { Toast.makeText(this, "无法打开微博", Toast.LENGTH_SHORT).show() }
    }

    private fun tagColor(t: String): Int = when (t) {
        "热" -> 0xFFFF9406.toInt(); "新" -> 0xFFFF3852.toInt(); "沸" -> 0xFFF26D5F.toInt(); "爆" -> 0xFFBF1B14.toInt()
        else -> 0xFFE2493F.toInt()
    }

    private fun weiboBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hdr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(4)) }
        hdr.addView(weiboLogo(), LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(8) })
        val tc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tc.addView(TextView(this).apply { text = "微博热搜"; textSize = 16f; setTextColor(INK); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        tc.addView(TextView(this).apply { text = "实时热点 · 点击查看"; textSize = 11f; setTextColor(textSub) })
        hdr.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
        hdr.addView(TextView(this).apply {
            text = "↻"; textSize = 20f; setTextColor(OLIVE); setPadding(dp(12), dp(4), dp(4), dp(4)); setOnClickListener { loadWeibo() }
        })
        box.addView(hdr)
        val rows = (sp.getString("wb", null) ?: "").split("\n").filter { it.isNotBlank() }
        if (rows.isEmpty()) {
            box.addView(TextView(this).apply { text = "正在获取热搜…"; textSize = 13f; setTextColor(textSub); setPadding(0, dp(8), 0, 0) })
            return box
        }
        rows.take(8).forEachIndexed { i, line ->
            val f = line.split("\t")
            val word = f[0]; val heat = f.getOrNull(1) ?: ""; val tag = f.getOrNull(2) ?: ""
            if (i > 0) box.addView(View(this).apply { setBackgroundColor(0x14000000) }, LinearLayout.LayoutParams(-1, dp(1)))
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
            row.addView(TextView(this).apply {
                text = (i + 1).toString(); textSize = 15f; gravity = Gravity.CENTER
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(when (i) { 0 -> 0xFFF5222D.toInt(); 1 -> 0xFFFF7A00.toInt(); 2 -> 0xFFE6A100.toInt(); else -> INK_SUB })
            }, LinearLayout.LayoutParams(dp(24), -2))
            row.addView(TextView(this).apply {
                text = word; textSize = 15f; setTextColor(INK); maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(dp(6), 0, dp(6), 0)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            if (tag.isNotBlank()) row.addView(TextView(this).apply {
                text = tag; textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(dp(5), dp(1), dp(5), dp(1))
                background = GradientDrawable().apply { setColor(tagColor(tag)); cornerRadius = dp(4).toFloat() }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            if (heat.isNotBlank()) row.addView(TextView(this).apply { text = heat; textSize = 12f; setTextColor(textSub) })
            row.setOnClickListener { openWeibo(word) }
            box.addView(row)
        }
        return box
    }

    // ---------- 快捷方式卡片（入口取自用户的天气应用） ----------
    private fun appIcon(pkg: String) = all.firstOrNull { it.pkg == pkg }?.icon

    private fun wechatScan() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setComponent(ComponentName("com.tencent.mm", "com.tencent.mm.ui.LauncherUI"))
                .putExtra("LauncherUI.From.Scaner.Shortcut", true).putExtra("LauncherUI.Shortcut.LaunchType", "launch_type_scan_qrcode").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        } catch (e: Exception) { Toast.makeText(this, "没有找到微信", Toast.LENGTH_SHORT).show() }
    }

    private fun alipay(saId: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("alipayqr://platformapi/startapp?saId=" + saId)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { Toast.makeText(this, "没有找到支付宝", Toast.LENGTH_SHORT).show() }
    }

    private fun tile(label: String, iconName: String, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(8))
            background = GradientDrawable().apply { setColor(0x1AFFFFFF); cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0x26FFFFFF) }
            val id = resources.getIdentifier(iconName, "drawable", packageName)
            if (id != 0) addView(ImageView(context).apply { setImageResource(id); scaleType = ImageView.ScaleType.FIT_CENTER; setColorFilter(0xFFF3F5F9.toInt(), android.graphics.PorterDuff.Mode.SRC_ATOP) },
                LinearLayout.LayoutParams(dp(30), dp(30)))
            addView(TextView(context).apply { text = label; textSize = 11f; gravity = Gravity.CENTER; setTextColor(INK); setPadding(0, dp(5), 0, 0) })
            setOnClickListener { onClick() }
        }

    private fun shortcutBody(): View {
        val row = LinearLayout(this)
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val now = java.util.Date()
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            text = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH).toString()
            textSize = 40f; includeFontPadding = false; setTextColor(OLIVE); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        val dcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        dcol.addView(TextView(this).apply { text = java.text.SimpleDateFormat("yyyy年M月", java.util.Locale.CHINA).format(now); textSize = 13f; setTextColor(INK) })
        dcol.addView(TextView(this).apply { text = java.text.SimpleDateFormat("EEEE", java.util.Locale.CHINA).format(now); textSize = 13f; setTextColor(INK_SUB) })
        top.addView(dcol)
        left.addView(top)
        val lunar = try {
            val gz = android.icu.text.SimpleDateFormat("U", android.icu.util.ULocale("zh_CN@calendar=chinese")).format(now)
            val md = android.icu.text.SimpleDateFormat("MMMMd", android.icu.util.ULocale("zh_CN@calendar=chinese")).format(now)
            val zodiac = "鼠牛虎兔龙蛇马羊猴鸡狗猪"[((java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) - 4) % 12 + 12) % 12]
            gz + zodiac + "年" + md
        } catch (e: Exception) { "" }
        if (lunar.isNotEmpty()) left.addView(TextView(this).apply { text = lunar; textSize = 12f; setTextColor(INK_SUB); setPadding(0, dp(6), 0, 0) })
        val p = (sp.getString("wx", null) ?: "").split("|")
        if (p.size >= 9) {
            val w = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, 0) }
            wxIcon(p[2], dp(22))?.let { ic -> w.addView(ImageView(this).apply { setImageDrawable(ic) }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(6) }) }
            w.addView(TextView(this).apply { text = p[2] + " " + p[1] + "°"; textSize = 15f; setTextColor(INK); setTypeface(typeface, android.graphics.Typeface.BOLD) })
            left.addView(w)
            left.addView(TextView(this).apply { text = "体感 " + p[3] + "°"; textSize = 12f; setTextColor(INK_SUB); setPadding(0, dp(3), 0, 0) })
            left.addView(TextView(this).apply { text = if (p.size >= 10 && p[9].isNotBlank()) p[9] else "暂无短时降水信息"; textSize = 12f; setTextColor(INK_SUB); setPadding(0, dp(3), 0, 0) })
        }
        row.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun pair(a: View, b: View): LinearLayout = LinearLayout(this).apply {
            addView(a, LinearLayout.LayoutParams(0, dp(78), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            addView(b, LinearLayout.LayoutParams(0, dp(78), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        grid.addView(pair(tile("微信扫一扫", "sc_ic_wx_scan") { wechatScan() }, tile("支付宝扫一扫", "sc_ic_ali_scan") { alipay("10000007") }))
        grid.addView(pair(tile("乘车码", "sc_ic_bus") { alipay("200011235") }, tile("付款码", "sc_ic_pay") { alipay("20000056") }))
        row.addView(grid, LinearLayout.LayoutParams(0, -2, 1.15f).apply { leftMargin = dp(8) })
        return row
    }

    // ---------- 音乐卡片：黑胶 / 歌词 / 律动条 ----------
    private var mTitle: TextView? = null
    private var mArtist: TextView? = null
    private var mTimeCur: TextView? = null
    private var mTimeTot: TextView? = null
    private var mBar: ProgressBar? = null
    private var mWave: ImageView? = null
    private var mArt: ImageView? = null
    private var mWavePlaying: Boolean? = null
    private var mPlayShown = -1
    private var mLyric1: TextView? = null
    private var mLyric2: TextView? = null
    private var mPlay: ImageView? = null
    private var mVinyl: VinylView? = null
    private var mCtl: android.media.session.MediaController? = null
    private var lyricKey = ""
    private var lyrics: List<Pair<Long, String>> = emptyList()
    private var tickOn = false
    private var tickN = 0
    private val ticker = object : Runnable {
        override fun run() {
            if (!negativeOpen || mVinyl == null) { tickOn = false; return }
            musicTick()
            root.postDelayed(this, 33)
        }
    }

    private fun resId(n: String): Int = resources.getIdentifier(n, "drawable", packageName)

    private fun bmpRes(n: String): android.graphics.Bitmap? {
        val id = resId(n)
        return if (id == 0) null else try { android.graphics.BitmapFactory.decodeResource(resources, id) } catch (e: Exception) { null }
    }

    private inner class VinylView(c: Context) : View(c) {
        var cover: android.graphics.Bitmap? = null
        var playing = false
        private var angle = 0f
        private var arm = 0f
        private val disc = bmpRes("music_vinyl_disc_bg")
        private val ring = bmpRes("music_center_gold_ring")
        private val defCover = bmpRes("ic_music_vinyl_center")
        private val armBmp = bmpRes("music_tonearm")
        private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
        private val path = android.graphics.Path()
        private val m = android.graphics.Matrix()
        fun tick() {
            if (playing) angle = (angle + 1.2f) % 360f
            arm += ((if (playing) 1f else 0f) - arm) * 0.15f
            invalidate()
        }
        override fun onDraw(cv: android.graphics.Canvas) {
            val s = minOf(width, height).toFloat()
            val ox = (width - s) / 2f
            val cx = ox + s * 0.52f
            val cy = s * 0.57f
            val r = s * 0.40f
            cv.save(); cv.rotate(angle, cx, cy)
            if (disc != null) cv.drawBitmap(disc, null, android.graphics.RectF(cx - r, cy - r, cx + r, cy + r), p)
            else { p.style = android.graphics.Paint.Style.FILL; p.color = 0xFF141414.toInt(); cv.drawCircle(cx, cy, r, p) }
            val lr = r * 0.44f
            val cb = cover ?: defCover
            if (cb != null) {
                cv.save(); path.reset(); path.addCircle(cx, cy, lr, android.graphics.Path.Direction.CW); cv.clipPath(path)
                cv.drawBitmap(cb, null, android.graphics.RectF(cx - lr, cy - lr, cx + lr, cy + lr), p); cv.restore()
            }
            if (ring != null) cv.drawBitmap(ring, null, android.graphics.RectF(cx - lr * 1.05f, cy - lr * 1.05f, cx + lr * 1.05f, cy + lr * 1.05f), p)
            cv.restore()
            // 唱臂：支点在唱片左上角外侧。播放时针尖落在唱片外圈纹路上（不碰中间封面），停止时摆到唱片左边。
            val bm = armBmp
            if (bm != null) {
                val sx = bm.width / 52f
                val sy = bm.height / 86f
                val pxN = 15.7f * sx; val pyN = 11f * sy
                val txN = 49.5f * sx; val tyN = 81f * sy
                val px = ox + s * 0.07f
                val py = s * 0.05f
                val tx = cx + r * 0.72f * -0.84f
                val ty = cy + r * 0.72f * -0.54f
                val len0 = Math.hypot((txN - pxN).toDouble(), (tyN - pyN).toDouble()).toFloat()
                val k = Math.hypot((tx - px).toDouble(), (ty - py).toDouble()).toFloat() / len0
                val aPlay = Math.atan2((ty - py).toDouble(), (tx - px).toDouble())
                val aRest = Math.atan2(1.0, -0.12)
                val a = aRest + (aPlay - aRest) * arm
                val a0 = Math.atan2((tyN - pyN).toDouble(), (txN - pxN).toDouble())
                m.reset()
                m.postTranslate(-pxN, -pyN)
                m.postScale(k, k)
                m.postRotate(Math.toDegrees(a - a0).toFloat())
                m.postTranslate(px, py)
                cv.drawBitmap(bm, m, p)
            }
        }
    }

    private fun listenerEnabled(): Boolean =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)

    private fun pickController(): android.media.session.MediaController? {
        if (!listenerEnabled()) return null
        return try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as android.media.session.MediaSessionManager
            val l = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            l.firstOrNull { it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
        } catch (e: Exception) { null }
    }

    private fun musicTap() {
        if (!listenerEnabled()) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); return }
        val pk = mCtl?.packageName ?: return
        packageManager.getLaunchIntentForPackage(pk)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun fmtMs(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0') }

    private fun pollMusic() {
        val c = pickController(); mCtl = c
        val md = c?.metadata
        if (c == null || md == null) {
            mTitle?.text = "未在播放"
            mArtist?.text = if (listenerEnabled()) "打开音乐App开始播放" else "点击授权通知使用权"
            mLyric1?.text = "♪ 等待歌词…"; mLyric2?.text = ""
            mTimeCur?.text = "0:00"; mTimeTot?.text = "0:00"; mBar?.progress = 0
            mVinyl?.cover = null; mArt?.setImageResource(resId("ic_music_vinyl_center"))
            return
        }
        val title = md.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val artist = md.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: md.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        mTitle?.text = if (title.isBlank()) "未知歌曲" else title
        mArtist?.text = artist
        val bmp = md.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(android.media.MediaMetadata.METADATA_KEY_ART)
        mVinyl?.cover = bmp
        if (bmp != null) mArt?.setImageBitmap(bmp) else mArt?.setImageResource(resId("ic_music_vinyl_center"))
        fetchLyrics(title, artist)
    }

    private fun updateProgressAndLyric() {
        val c = mCtl ?: return
        val st = c.playbackState ?: return
        val playing = st.state == android.media.session.PlaybackState.STATE_PLAYING
        var pos = st.position
        if (playing) pos += ((android.os.SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        val dur = c.metadata?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        mTimeCur?.text = fmtMs(pos); mTimeTot?.text = fmtMs(dur)
        mBar?.progress = if (dur > 0) (pos * 1000 / dur).toInt().coerceIn(0, 1000) else 0
        val shown = if (playing) 1 else 0
        if (shown != mPlayShown) { mPlayShown = shown; mPlay?.setImageResource(resId(if (playing) "ic_music_pause" else "ic_music_play")) }
        val ls = lyrics
        if (ls.isEmpty()) { mLyric1?.text = "♪ 等待歌词…"; mLyric2?.text = ""; return }
        var i = ls.indexOfLast { it.first <= pos + 300 }
        if (i < 0) i = 0
        mLyric1?.text = ls[i].second
        mLyric2?.text = ls.getOrNull(i + 1)?.second ?: ""
    }

    private fun setWave(playing: Boolean) {
        val w = mWave ?: return
        if (!playing) { w.setImageResource(resId("music_wave_static")); return }
        val ad = android.graphics.drawable.AnimationDrawable()
        for (i in 0..15) { val id = resId("music_wave_f" + i); if (id != 0) ad.addFrame(resources.getDrawable(id, theme), 90) }
        ad.isOneShot = false
        w.setImageDrawable(ad); ad.start()
    }

    private fun musicTick() {
        tickN++
        val v = mVinyl ?: return
        if (tickN % 15 == 1) pollMusic()
        val playing = mCtl?.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
        v.playing = playing
        v.tick()
        if (mWavePlaying != playing) { mWavePlaying = playing; setWave(playing) }
        if (tickN % 6 == 0) updateProgressAndLyric()
    }

    private fun httpGet(u: String, ref: String? = null): String {
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
        if (ref != null) c.setRequestProperty("Referer", ref)
        try { return c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    private fun enc(t: String): String = java.net.URLEncoder.encode(t, "UTF-8")

    private fun fetchLyrics(title: String, artist: String) {
        val key = title + "|" + artist
        if (key == lyricKey) return
        lyricKey = key; lyrics = emptyList()
        if (title.isBlank()) return
        Thread {
            var lrc = ""
            try {
                val s = org.json.JSONObject(httpGet("https://music.163.com/api/search/get?s=" + enc(title + " " + artist) + "&type=1&limit=1", "https://music.163.com/"))
                val id = s.getJSONObject("result").getJSONArray("songs").getJSONObject(0).getLong("id")
                lrc = org.json.JSONObject(httpGet("https://music.163.com/api/song/lyric?id=" + id + "&lv=1&kv=1&tv=-1", "https://music.163.com/"))
                    .getJSONObject("lrc").optString("lyric", "")
            } catch (e: Exception) {}
            if (lrc.isBlank()) try {
                lrc = org.json.JSONObject(httpGet("https://lrclib.net/api/get?artist_name=" + enc(artist) + "&track_name=" + enc(title))).optString("syncedLyrics", "")
            } catch (e: Exception) {}
            if (lyricKey == key) lyrics = parseLrc(lrc)
        }.start()
    }

    private fun parseLrc(t: String): List<Pair<Long, String>> {
        val re = Regex("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]")
        val out = ArrayList<Pair<Long, String>>()
        for (line in t.split("\n")) {
            val ms = re.findAll(line).toList()
            if (ms.isEmpty()) continue
            val text = line.substring(ms.last().range.last + 1).trim()
            if (text.isEmpty()) continue
            for (m in ms) {
                val mm = m.groupValues[1].toLong(); val ss = m.groupValues[2].toLong()
                val fr = m.groupValues[3]
                val f = if (fr.isEmpty()) 0L else fr.padEnd(3, '0').take(3).toLong()
                out.add(((mm * 60 + ss) * 1000 + f) to text)
            }
        }
        return out.sortedBy { it.first }
    }

    private fun musicBody(): View {
        mPlayShown = -1; mWavePlaying = null
        val panels = LinearLayout(this).apply { minimumHeight = dp(196) }
        // 左：橄榄绿面板（封面 / 歌名 / 进度 / 控制）
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(10), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x30FFFFFF, 0x10FFFFFF)).apply { cornerRadius = dp(10).toFloat(); setStroke(dp(1), 0x22FFFFFF) }
        }
        mArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { setColor(0x1AFFFFFF); cornerRadius = dp(10).toFloat(); setStroke(dp(1), 0x33FFFFFF) }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(10).toFloat()) }
            }
            clipToOutline = true
            val id = resId("ic_music_vinyl_center"); if (id != 0) setImageResource(id)
            setOnClickListener { musicTap() }
        }
        left.addView(mArt, LinearLayout.LayoutParams(dp(52), dp(52)))
        mTitle = TextView(this).apply {
            textSize = 14f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(8), 0, 0)
            setTextColor(BEIGE); setTypeface(typeface, android.graphics.Typeface.BOLD); setOnClickListener { musicTap() }
        }
        mArtist = TextView(this).apply {
            textSize = 11f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setTextColor(BEIGE_SUB); setOnClickListener { musicTap() }
        }
        left.addView(mTitle); left.addView(mArtist)
        left.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        val tr = LinearLayout(this)
        mTimeCur = TextView(this).apply { textSize = 10f; setTextColor(BEIGE_SUB); text = "0:00" }
        mTimeTot = TextView(this).apply { textSize = 10f; setTextColor(BEIGE_SUB); gravity = Gravity.END; text = "0:00" }
        tr.addView(mTimeCur, LinearLayout.LayoutParams(0, -2, 1f)); tr.addView(mTimeTot, LinearLayout.LayoutParams(0, -2, 1f))
        left.addView(tr)
        mBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(BEIGE)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0x33FFFFFF)
        }
        left.addView(mBar, LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(4) })
        fun ctl(name: String, act: () -> Unit): ImageView = ImageView(this).apply {
            val id = resId(name); if (id != 0) setImageResource(id)
            scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(6), dp(6), dp(6), dp(6)); setOnClickListener { act() }
        }
        mPlay = ctl("ic_music_play") {
            val c = mCtl
            if (c?.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) c.transportControls.pause() else c?.transportControls?.play()
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
        row.addView(ctl("ic_music_prev") { mCtl?.transportControls?.skipToPrevious() }, LinearLayout.LayoutParams(0, dp(36), 1f))
        row.addView(mPlay, LinearLayout.LayoutParams(0, dp(36), 1f))
        row.addView(ctl("ic_music_next") { mCtl?.transportControls?.skipToNext() }, LinearLayout.LayoutParams(0, dp(36), 1f))
        left.addView(row)
        panels.addView(left, LinearLayout.LayoutParams(0, -1, 46f).apply { setMargins(dp(8), dp(8), 0, dp(8)) })
        // 右：米色面板（标题 / 黑胶 / 歌词 / 律动条）
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(8), 0) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = "听见·好声音！"; textSize = 12f; setTextColor(INK); setTypeface(typeface, android.graphics.Typeface.BOLD) },
            LinearLayout.LayoutParams(0, -2, 1f))
        val lid = resId("ic_music_logo_eq")
        if (lid != 0) head.addView(ImageView(this).apply { setImageResource(lid); scaleType = ImageView.ScaleType.FIT_END; setColorFilter(0xCCF3F5F9.toInt(), android.graphics.PorterDuff.Mode.SRC_ATOP) }, LinearLayout.LayoutParams(dp(44), dp(30)))
        right.addView(head)
        val vinyl = VinylView(this); mVinyl = vinyl
        right.addView(vinyl, LinearLayout.LayoutParams(dp(104), dp(104)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        mLyric1 = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(INK); setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(2), 0, 0)
        }
        mLyric2 = TextView(this).apply {
            textSize = 11f; gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setTextColor(INK_SUB)
        }
        right.addView(mLyric1, LinearLayout.LayoutParams(-1, -2)); right.addView(mLyric2, LinearLayout.LayoutParams(-1, -2))
        right.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        mWave = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY; alpha = 0.95f; setColorFilter(accent, android.graphics.PorterDuff.Mode.SRC_ATOP) }
        right.addView(mWave, LinearLayout.LayoutParams(-1, dp(24)).apply { bottomMargin = dp(6) })
        panels.addView(right, LinearLayout.LayoutParams(0, -1, 54f))
        pollMusic(); updateProgressAndLyric()
        return panels
    }

    private fun startMusicTicker() {
        if (tickOn || !negativeOpen) return
        tickOn = true; root.post(ticker)
    }

    private fun batteryBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else 0
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        box.addView(TextView(this).apply {
            text = "$pct%  ·  " + (if (charging) "充电中" else "未充电") + "  ·  " + temp + "°C"
            textSize = 18f; setTextColor(textMain)
        })
        box.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = pct
            progressTintList = android.content.res.ColorStateList.valueOf(OLIVE)
        }, LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(10) })
        return box
    }

    private fun todos(): MutableList<String> =
        (sp.getString("todos", "") ?: "").split("\n").filter { it.length > 2 }.toMutableList()

    private fun saveTodos(l: List<String>) { sp.edit().putString("todos", l.joinToString("\n")).apply() }

    private fun todoBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tl = todos()
        if (tl.isNotEmpty()) box.addView(TextView(this).apply {
            text = "已完成 " + tl.count { it.startsWith("1|") } + " / " + tl.size; textSize = 12f; setTextColor(OLIVE)
        })
        todos().forEachIndexed { idx, raw ->
            val done = raw.startsWith("1|")
            val label = raw.substring(2)
            box.addView(TextView(this).apply {
                text = (if (done) "☑  " else "☐  ") + label
                textSize = 15f; setTextColor(if (done) textSub else textMain)
                if (done) paintFlags = paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener {
                    val l = todos()
                    if (idx < l.size) { l[idx] = (if (done) "0|" else "1|") + label; saveTodos(l); renderCards() }
                }
                setOnLongClickListener {
                    val l = todos()
                    if (idx < l.size) { l.removeAt(idx); saveTodos(l); renderCards() }
                    true
                }
            })
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            hint = "添加待办…"; setSingleLine(); textSize = 15f; setTextColor(textMain); setHintTextColor(textSub)
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply {
            text = "+"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(ON_ACCENT)
            background = GradientDrawable().apply { setColor(OLIVE); cornerRadius = dp(18).toFloat() }
            setOnClickListener {
                val t = input.text.toString().trim().replace("\n", " ")
                if (t.isNotEmpty()) { val l = todos(); l.add("0|" + t); saveTodos(l); renderCards() }
            }
        }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { leftMargin = dp(10) })
        box.addView(row)
        return box
    }

    // ---------- 天气卡片（小米天气接口，取自你提供的天气应用） ----------
    private val reqLoc = 9303
    private var wxFetching = false
    private val wxCodes = mapOf(0 to "晴", 1 to "多云", 2 to "阴", 3 to "阵雨", 4 to "雷阵雨", 5 to "雷阵雨伴冰雹",
        6 to "雨夹雪", 7 to "小雨", 8 to "中雨", 9 to "大雨", 10 to "暴雨", 11 to "大暴雨", 12 to "特大暴雨",
        13 to "阵雪", 14 to "小雪", 15 to "中雪", 16 to "大雪", 17 to "暴雪", 18 to "雾", 19 to "冻雨",
        20 to "沙尘暴", 29 to "浮尘", 30 to "扬沙", 31 to "强沙尘暴", 32 to "浓雾", 49 to "强浓雾",
        53 to "霾", 54 to "中度霾", 55 to "重度霾", 56 to "严重霾", 57 to "大雾", 58 to "特强浓雾", 301 to "雨", 302 to "雪")

    private fun hasLoc() = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private val wxOpenNames = listOf("内置天气", "外部天气应用")

    private fun onWeatherTap() {
        if (gi("wxopen", 0) == 0) { startActivity(Intent(this, WeatherActivity::class.java)); return }
        if (!hasLoc()) { requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), reqLoc); return }
        val i = listOf("com.weather.app", "com.miui.weather2").firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else Toast.makeText(this, "没找到天气应用", Toast.LENGTH_SHORT).show()
    }

    private fun weatherBody(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val p = (sp.getString("wx", null) ?: "").split("|")
        if (p.size < 9) {
            box.addView(TextView(this).apply {
                text = if (hasLoc()) "正在获取天气…" else "点击卡片授权定位，显示当地天气"
                textSize = 14f; setTextColor(BEIGE_SUB); setPadding(0, dp(6), 0, 0)
            })
            return box
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        wxIcon(p[2], dp(56))?.let { ic ->
            row.addView(ImageView(this).apply { setImageDrawable(ic) }, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(12) })
        }
        row.addView(TextView(this).apply {
            text = p[1] + "°"; textSize = 42f; setTextColor(BEIGE); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        row.addView(TextView(this).apply { text = "  " + p[2]; textSize = 18f; setTextColor(BEIGE); setPadding(0, 0, 0, dp(8)) })
        box.addView(row)
        box.addView(TextView(this).apply {
            text = p[0] + "  ·  最高" + p[6] + "°  最低" + p[7] + "°"; textSize = 14f; setTextColor(BEIGE_SUB)
        })
        box.addView(TextView(this).apply {
            text = "体感" + p[3] + "°  ·  湿度" + p[4] + "%" + (if (p[5].isNotBlank()) "  ·  空气 " + p[5] else "")
            textSize = 14f; setTextColor(BEIGE_SUB); setPadding(0, dp(4), 0, 0)
        })
        return box
    }

    private fun lastLoc(): android.location.Location? {
        val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        var best: android.location.Location? = null
        for (prov in lm.getProviders(true)) {
            try {
                val l = lm.getLastKnownLocation(prov)
                if (l != null && (best == null || l.time > best.time)) best = l
            } catch (e: SecurityException) {}
        }
        return best
    }

    private fun maybeLoadWeather() {
        if (wxFetching || !hasLoc()) return
        if (System.currentTimeMillis() - sp.getLong("wx_t", 0L) < 20 * 60 * 1000L) return
        val l = lastLoc()
        if (l != null) { fetchWeather(l.latitude, l.longitude); return }
        if (Build.VERSION.SDK_INT >= 30) {
            val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            val prov = lm.getProviders(true).firstOrNull { it != android.location.LocationManager.PASSIVE_PROVIDER } ?: return
            try {
                lm.getCurrentLocation(prov, null, mainExecutor) { loc -> if (loc != null) fetchWeather(loc.latitude, loc.longitude) }
            } catch (e: SecurityException) {}
        }
    }

    private fun http(u: String): String {
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Mobile")
        c.setRequestProperty("Accept", "application/json")
        try { return c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    private fun fetchWeather(lat: Double, lon: Double) {
        if (wxFetching) return
        wxFetching = true
        Thread {
            try {
                val base = "https://weatherapi.market.xiaomi.com/wtr-v3/"
                var key = "weathercn:" + String.format(java.util.Locale.US, "%.3f,%.3f", lon, lat)
                var name = "当前位置"
                try {
                    val g = org.json.JSONArray(http(base + "location/city/geo?latitude=" + lat + "&longitude=" + lon + "&locale=zh_cn"))
                    if (g.length() > 0) {
                        val o = g.getJSONObject(0)
                        key = o.optString("locationKey", key); name = o.optString("name", name)
                    }
                } catch (e: Exception) {}
                val q = "latitude=" + lat + "&longitude=" + lon + "&locationKey=" + java.net.URLEncoder.encode(key, "UTF-8") +
                    "&days=15&appKey=weather20151024&sign=zUFJoAR2ZVrDy1vF3D07&isGlobal=false&isLocated=true&locale=zh_cn"
                val j = org.json.JSONObject(http(base + "weather/all?" + q))
                val cur = j.getJSONObject("current")
                fun v(o: org.json.JSONObject?, k: String): String = o?.optJSONObject(k)?.optString("value", "") ?: ""
                val temp = Math.round(v(cur, "temperature").toDoubleOrNull() ?: 0.0)
                val feels = Math.round(v(cur, "feelsLike").toDoubleOrNull() ?: temp.toDouble())
                val hum = Math.round(v(cur, "humidity").toDoubleOrNull() ?: 0.0)
                val text = wxCodes[cur.optString("weather", "1").toIntOrNull() ?: 1] ?: "多云"
                val aqi = j.optJSONObject("aqi")?.optString("aqi", "") ?: ""
                val dt = j.optJSONObject("forecastDaily")?.optJSONObject("temperature")?.optJSONArray("value")
                val hi = dt?.optJSONObject(0)?.optString("from", "") ?: ""
                val lo = dt?.optJSONObject(0)?.optString("to", "") ?: ""
                var tip = "未来短时内无明显降水。"
                val fh = j.optJSONObject("forecastHourly")
                val pops = fh?.optJSONObject("precipitationProbability")?.optJSONArray("value")
                val curCode = cur.optString("weather", "1").toIntOrNull() ?: 1
                if (curCode in setOf(3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 19, 301)) tip = "当前有降水，出行请带伞"
                else if (pops != null) {
                    for (k in 0 until minOf(2, pops.length())) {
                        if (pops.optDouble(k, 0.0) >= 50.0) { tip = if (k == 0) "短时内可能有降水，出行请带伞" else "约1小时后可能有降水"; break }
                    }
                }
                var real = j.optString("forecastKeypoint", "")
                if (real.isBlank()) real = j.optString("forecast_keypoint", "")
                if (real.isBlank()) {
                    val mi = j.optJSONObject("minutely")
                    real = mi?.optString("description", "") ?: ""
                    if (real.isBlank()) real = mi?.optJSONObject("precipitation")?.optString("description", "") ?: ""
                }
                if (real.isNotBlank()) tip = real
                val line = listOf(name.replace("|", ""), temp.toString(), text, feels.toString(), hum.toString(), aqi, hi, lo, "ok", tip.replace("|", "").replace("\n", " ")).joinToString("|")
                sp.edit().putString("wx", line).putLong("wx_t", System.currentTimeMillis()).apply()
            } catch (e: Exception) {
            }
            runOnUiThread { wxFetching = false; updateGlance(); if (negativeOpen) renderCards() }
        }.start()
    }

    private fun pressSel(light: Boolean): android.graphics.drawable.Drawable = GradientDrawable().apply {
        setColor(if (light) 0x26FFFFFF else 0x16000000); cornerRadius = dp(22).toFloat()
    }

    private fun wxEmoji(t: String): String = when {
        t.contains("雷") -> "⛈"
        t.contains("雪") -> "❄️"
        t.contains("雨") -> "🌧"
        t.contains("雾") || t.contains("霾") || t.contains("沙") || t.contains("尘") -> "🌫"
        t.contains("阴") -> "☁️"
        t.contains("多云") -> "⛅"
        t.contains("晴") -> "☀️"
        else -> "🌤"
    }

    private fun wxIconName(t: String): String {
        val dn = if (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) in 6..17) "day" else "night"
        return when {
            t.contains("雷") -> "thunderstorm"
            t.contains("暴雪") || t.contains("大雪") -> "heavy_snow"
            t.contains("小雪") -> "light_snow_$dn"
            t.contains("雪") -> "snow"
            t.contains("暴雨") || t.contains("大雨") -> "heavy_rain"
            t.contains("小雨") || t.contains("毛毛") -> "light_rain_$dn"
            t.contains("雨") -> "rain"
            t.contains("雾") || t.contains("霾") || t.contains("沙") || t.contains("尘") -> "haze_fog_dust_smoke"
            t.contains("阴") -> "overcast"
            t.contains("多云") -> "partly_cloudy_$dn"
            t.contains("晴") -> "clear_$dn"
            else -> "not_available"
        }
    }

    private fun wxIcon(t: String, size: Int): android.graphics.drawable.Drawable? {
        val id = resources.getIdentifier("wx_" + wxIconName(t), "drawable", packageName)
        if (id == 0) return null
        return try { getDrawable(id)?.mutate()?.also { it.setBounds(0, 0, size, size) } } catch (e: Exception) { null }
    }

    private fun updateGlance() {
        if (!::glanceDate.isInitialized) return
        glanceDate.text = java.text.SimpleDateFormat("M月d日  EEEE", java.util.Locale.CHINA).format(java.util.Date())
        val p = (sp.getString("wx", null) ?: "").split("|")
        glanceWx.text = when {
            p.size >= 9 -> p[2] + "  " + p[1] + "°  ·  " + p[0]
            hasLoc() -> "正在获取天气…"
            else -> "点击授权定位，显示天气"
        }
        glanceWx.setCompoundDrawables(if (p.size >= 9) wxIcon(p[2], dp(26)) else null, null, null, null)
        glanceWx.compoundDrawablePadding = dp(8)
    }

    private fun customApp(a: App) {
        val opts = arrayOf("修改桌面名称", "从相册选择图标", "从图标包选择", "恢复默认图标/名称")
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("自定义 · ${displayLabel(a)}").setItems(opts) { _, i ->
            when (i) {
                0 -> renameApp(a)
                1 -> pickAppIcon(a)
                2 -> pickPackIcon(a)
                3 -> { sp.edit().remove("label:${a.key}").remove("icon:${a.key}").remove("packicon:${a.key}").apply(); load(); refresh() }
            }
        }.show()
    }

    private fun displayLabel(a: App) = sp.getString("label:${a.key}", null) ?: a.label

    private fun renameApp(a: App) {
        val input = EditText(this).apply { setSingleLine(); setText(displayLabel(a)); selectAll() }
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("修改桌面名称").setView(input).setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ -> sp.edit().putString("label:${a.key}", input.text.toString().trim().ifEmpty { a.label }).apply(); load(); refresh() }.show()
    }

    private val reqAppIcon = 9103
    private var pendingAppKey = ""
    private fun pickAppIcon(a: App) {
        pendingAppKey = a.key
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), reqAppIcon) }
        catch (e: Exception) { Toast.makeText(this, "找不到图片选择器", Toast.LENGTH_SHORT).show() }
    }

    private fun pickPackIcon(a: App) {
        if (packRes == null || packMap.isEmpty()) { Toast.makeText(this, "请先在设置里启用图标包", Toast.LENGTH_SHORT).show(); return }
        val names = packMap.entries.filter { it.key.substringBefore('/') == a.pkg }.map { it.value }.distinct()
        if (names.isEmpty()) { Toast.makeText(this, "这个图标包没有提供该应用的可选图标", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("选择 ${displayLabel(a)} 图标").setItems(names.toTypedArray()) { _, which ->
            sp.edit().putString("packicon:${a.key}", names[which]).apply(); load(); refresh()
        }.show()
    }

    private fun pinyin(s: String): Pair<String, String> {
        val t = try { tr?.transliterate(s) ?: s } catch (e: Exception) { s }
        val w = t.lowercase().split(" ").filter { it.isNotEmpty() }
        return w.joinToString("") to w.map { it[0] }.joinToString("")
    }

    // ---------- 图标包 ----------
    private var packRes: Resources? = null
    private var packPkg = ""
    private val packMap = HashMap<String, String>()

    private fun packs(): List<Pair<String, String>> {
        val acts = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME",
            "com.gau.go.launcherex.theme", "app.lawnchair.icons.THEMED_ICON")
        return acts.flatMap { packageManager.queryIntentActivities(Intent(it), 0) }
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
    }

    private fun loadPack() {
        packMap.clear(); packRes = null; packPkg = ""
        val pkg = sp.getString("pack", "") ?: ""
        if (pkg.isEmpty()) return
        try {
            val res = packageManager.getResourcesForApplication(pkg)
            val parser: XmlPullParser = try {
                XmlPullParserFactory.newInstance().newPullParser().also { it.setInput(res.assets.open("appfilter.xml"), null) }
            } catch (e: Exception) {
                res.getXml(res.getIdentifier("appfilter", "xml", pkg))
            }
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                    val c = parser.getAttributeValue(null, "component")
                    val d = parser.getAttributeValue(null, "drawable")
                    if (c != null && d != null && c.startsWith("ComponentInfo{")) {
                        val k = c.removePrefix("ComponentInfo{").removeSuffix("}")
                        val pk = k.substringBefore('/')
                        var cl = k.substringAfter('/', "")
                        if (cl.startsWith(".")) cl = pk + cl
                        if (cl.isNotEmpty()) packMap["$pk/$cl"] = d
                    }
                }
                ev = parser.next()
            }
            packRes = res; packPkg = pkg
        } catch (e: Exception) { packRes = null }
    }

    private fun packIcon(key: String): Drawable? {
        val r = packRes ?: return null
        val n = packMap[key] ?: return null
        val id = r.getIdentifier(n, "drawable", packPkg)
        if (id == 0) return null
        return try { r.getDrawable(id, null) } catch (e: Exception) { null }
    }

    private fun showPacks() {
        val p = packs()
        if (p.isEmpty()) { Toast.makeText(this, "未检测到图标包，请先安装", Toast.LENGTH_LONG).show(); return }
        val names = (listOf("系统默认") + p.map { it.first }).toTypedArray()
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("图标包").setItems(names) { _, i ->
            sp.edit().putString("pack", if (i == 0) "" else p[i - 1].second).apply()
            load(); refresh()
        }.show()
    }

    // ---------- 备份 / 恢复 ----------
    private val reqBackup = 7101
    private val reqRestore = 7102

    private fun prefsJson(): String { val j = JSONObject(); sp.all.forEach { (k, v) -> j.put(k, v) }; return j.toString() }

    private fun applyBackup(t: String) {
        val j = JSONObject(t); val e = sp.edit()
        j.keys().forEach { k ->
            when (val v = j.get(k)) {
                is Int -> e.putInt(k, v)
                is Long -> e.putLong(k, v)
                is Boolean -> e.putBoolean(k, v)
                is String -> e.putString(k, v)
                else -> {}
            }
        }
        e.apply(); load(); refresh()
    }

    private fun backupToFile() {
        try {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, "pixel-desk-backup.json"), reqBackup)
        } catch (e: Exception) { Toast.makeText(this, "无法打开文件选择器", Toast.LENGTH_SHORT).show() }
    }

    private fun restoreFromFile() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), reqRestore)
        } catch (e: Exception) { Toast.makeText(this, "无法打开文件选择器", Toast.LENGTH_SHORT).show() }
    }

    private fun backup() {
        val j = JSONObject(); sp.all.forEach { (k, v) -> j.put(k, v) }
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("pixel_desk", j.toString()))
        Toast.makeText(this, "布局已复制到剪贴板，请自行粘贴保存", Toast.LENGTH_LONG).show()
    }

    private fun restore() {
        try {
            val t = (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .primaryClip?.getItemAt(0)?.text.toString()
            val j = JSONObject(t); val e = sp.edit()
            j.keys().forEach { k ->
                when (val v = j.get(k)) {
                    is Int -> e.putInt(k, v)
                    is Boolean -> e.putBoolean(k, v)
                    is String -> e.putString(k, v)
                    else -> {}
                }
            }
            e.apply(); load(); refresh()
            Toast.makeText(this, "已恢复", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "剪贴板里没有有效备份", Toast.LENGTH_SHORT).show() }
    }

    private fun load() {
        dirty = false
        loadPack()
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(q, 0).filter { it.activityInfo.packageName != packageName }.map {
            val raw = it.loadLabel(pm).toString(); val key = it.activityInfo.packageName + "/" + it.activityInfo.name
            val l = sp.getString("label:$key", raw) ?: raw; val (p, i) = pinyin(l)
            val overrideName = sp.getString("packicon:$key", null)
            val overrideIcon = if (overrideName != null && packRes != null) (try { packRes!!.getDrawable(packRes!!.getIdentifier(overrideName, "drawable", packPkg), null) } catch (e: Exception) { null }) else null
            val uri = sp.getString("icon:$key", null)
            val custom = if (uri != null) (try { contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapDrawable(resources, BitmapFactory.decodeStream(it)) } } catch (e: Exception) { null }) else null
            App(l, key, custom ?: overrideIcon ?: packIcon(key) ?: it.loadIcon(pm), p, i)
        }.sortedBy { it.py }
        if (!sp.contains("dock")) {
            val intents = listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), Intent("android.media.action.IMAGE_CAPTURE"))
            val keys = intents.mapNotNull { pm.resolveActivity(it, 0)?.activityInfo?.packageName }
                .mapNotNull { p -> all.firstOrNull { it.pkg == p }?.key }.distinct()
            save("dock", keys)
        }
    }

    private fun homeSlots(): MutableList<String> {
        val raw = sp.getString("hslots", null) ?: return list("home")
        return raw.split(",").map { if (it.isEmpty()) "_" else it }.toMutableList()
    }

    private fun saveSlots(l: List<String>) {
        var e = l.size
        while (e > 0 && l[e - 1] == "_") e--
        sp.edit().putString("hslots", l.subList(0, e).joinToString(",")).apply()
    }

    private fun freeSlot(l: MutableList<String>): Int {
        val i = l.indexOf("_")
        if (i >= 0) return i
        l.add("_")
        return l.size - 1
    }

    private fun clearFromHome(key: String) {
        val l = homeSlots(); var ch = false
        for (i in l.indices) if (l[i] == key) { l[i] = "_"; ch = true }
        if (ch) saveSlots(l)
    }

    private inner class SlotAd(val data: List<App?>, val color: Int) : BaseAdapter() {
        var rowH = 0
        override fun getCount() = data.size
        override fun getItem(p: Int): Any? = data[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, g: ViewGroup?): View {
            val c = cell(data[p], color)
            if (rowH > 0) c.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH)
            return c
        }
    }

    private val badgeNames = listOf("数字", "圆点", "关")

    private fun applyBadge(tv: TextView, pkg: String) {
        val mode = gi("badge", 0)
        val n = if (pkg.isEmpty() || mode == 2) 0 else if (pkg.startsWith("dir:")) dirMembers(pkg.substring(4)).sumOf { MediaListener.counts[it.substringBefore('/')] ?: 0 } else (MediaListener.counts[pkg] ?: 0)
        if (n <= 0) { tv.visibility = View.GONE; return }
        val lp = tv.layoutParams as FrameLayout.LayoutParams
        if (mode == 1) {
            lp.width = dp(10); lp.height = dp(10); tv.text = ""; tv.minWidth = 0; tv.setPadding(0, 0, 0, 0)
            (tv.background as? GradientDrawable)?.cornerRadius = dp(5).toFloat()
        } else {
            lp.width = ViewGroup.LayoutParams.WRAP_CONTENT; lp.height = dp(18)
            tv.text = if (n > 99) "99+" else n.toString(); tv.minWidth = dp(18); tv.setPadding(dp(4), 0, dp(4), 0)
            (tv.background as? GradientDrawable)?.cornerRadius = dp(9).toFloat()
        }
        tv.layoutParams = lp
        tv.visibility = View.VISIBLE
    }

    private fun updateBadges() {
        fun walk(v: View) {
            val t = v.tag
            if (v is TextView && t is String && t.startsWith("bdg:")) applyBadge(v, t.substring(4))
            else if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        if (::home.isInitialized) walk(home)
        if (::drawer.isInitialized) walk(drawer)
    }

    private inner class Ad(val data: List<App>, val color: Int) : BaseAdapter() {
        override fun getCount() = data.size
        override fun getItem(p: Int) = data[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, g: ViewGroup?): View {
            val a = data[p]
            if (v is LinearLayout && v.tag == "cell") {
                v.alpha = 1f
                val fl = v.getChildAt(0) as FrameLayout
                (fl.getChildAt(0) as ImageView).setImageDrawable(a.icon)
                (fl.getChildAt(1) as TextView).let { it.tag = "bdg:" + a.pkg; applyBadge(it, a.pkg) }
                (v.getChildAt(1) as? TextView)?.text = a.label
                return v
            }
            return cell(a, color)
        }
    }

    private fun cell(a: App?, color: Int, showLabel: Boolean = true): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), dp(10), dp(2), dp(6)); tag = "cell"
        clipChildren = false
        val s = dp(sizes[gi("size", 1)])
        val iv = ImageView(context).apply { setImageDrawable(a?.icon); elevation = dp(2).toFloat() }
        val r = when (gi("shape", 1)) { 0 -> 0.5f; 1 -> 0.28f; else -> 0f }
        if (r > 0f) {
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, v.width * r) }
            }
            iv.clipToOutline = true
        }
        val fl = FrameLayout(context).apply { clipChildren = false }
        fl.addView(iv, FrameLayout.LayoutParams(s, s))
        val bd = TextView(context).apply {
            tag = "bdg:" + (a?.pkg ?: "")
            elevation = dp(6).toFloat()
            textSize = 10f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); includeFontPadding = false
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply { setColor(0xFFE53935.toInt()); cornerRadius = dp(9).toFloat() }
            visibility = View.GONE
        }
        fl.addView(bd, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(18), Gravity.TOP or Gravity.END))
        addView(fl, LinearLayout.LayoutParams(s, s))
        if (a != null) applyBadge(bd, a.pkg)
        if (showLabel && sp.getBoolean("label", true)) addView(TextView(context).apply {
            text = a?.label ?: " "; setTextColor(color); textSize = 12f; maxLines = 1; gravity = Gravity.CENTER
            ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0)
            if (color == 0xFFFFFFFF.toInt()) setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
        })
        if (a == null) { tag = "empty"; for (i in 0 until childCount) getChildAt(i).visibility = View.INVISIBLE }
    }

    private inner class Pager(c: Context) : HorizontalScrollView(c) {
        var onPage: (Int) -> Unit = {}
        private var flung = false
        init { isHorizontalScrollBarEnabled = false; overScrollMode = OVER_SCROLL_NEVER }
        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.action == MotionEvent.ACTION_DOWN) flung = false
            val r = super.onTouchEvent(ev)
            if ((ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) && !flung) snap(0)
            return r
        }
        override fun fling(velocityX: Int) { flung = true; snap(velocityX) }
        private fun snap(v: Int) {
            val w = width
            if (w == 0) return
            val c = scrollX.toFloat() / w
            var t = when {
                v > 600 -> Math.ceil(c.toDouble()).toInt()
                v < -600 -> Math.floor(c.toDouble()).toInt()
                else -> Math.round(c)
            }
            t = t.coerceIn(0, pageCount - 1)
            smoothScrollTo(t * w, 0); onPage(t)
        }
    }

    private fun buildPages(slots: List<App?>) {
        val ps = cols * rows
        val last = slots.indexOfLast { it != null }
        pageCount = if (last < 0) 1 else (last / ps + 1) + (if (last / ps + 1 < 8) 1 else 0)
        cur = cur.coerceIn(0, pageCount - 1)
        val pw = resources.displayMetrics.widthPixels - dp(16)
        pagerBox.removeAllViews()
        for (i in 0 until pageCount) pagerBox.addView(GridView(this).apply {
            numColumns = cols; verticalSpacing = dp(4); setSelector(android.R.color.transparent)
            val page = List(ps) { k -> slots.getOrNull(i * ps + k) }
            val ad = SlotAd(page, 0xFFFFFFFF.toInt())
            adapter = ad
            post {
                if (height > 0) {
                    val natural = dp(sizes[gi("size", 1)]) + dp(40)
                    val rh = maxOf((height - dp(4) * (rows - 1)) / rows, natural)
                    if (ad.rowH != rh) { ad.rowH = rh; ad.notifyDataSetChanged() }
                }
            }
            setOnItemClickListener { _, v, p, _ -> (adapter as SlotAd).data[p]?.let { launch(it, v) } }
            setOnItemLongClickListener { _, v, p, _ ->
                val a = (adapter as SlotAd).data[p]
                if (a != null) { menuShown = true; startDrag(a, 1, v) }
                true
            }
        }, LinearLayout.LayoutParams(pw, -1))
        pager.post { pager.scrollTo(cur * pw, 0) }
        drawDots()
    }

    private fun drawDots() {
        dots.removeAllViews()
        if (pageCount < 2 || !sp.getBoolean("dots", true)) return
        for (i in 0 until pageCount) dots.addView(View(this).apply {
            background = GradientDrawable().apply {
                setColor(if (i == cur) 0xFFFFFFFF.toInt() else 0x66FFFFFF)
                cornerRadius = dp(3).toFloat()
            }
        }, LinearLayout.LayoutParams(if (i == cur) dp(16) else dp(6), dp(6)).apply { setMargins(dp(3), 0, dp(3), 0) })
    }

    // ---------- 拖拽排序 ----------
    private fun startDrag(a: App, where: Int, v: View) {
        dragApp = a; dragWhere = where; dragChanged = false; dragMoved = false; dragX0 = -1f
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        v.startDragAndDrop(ClipData.newPlainText("app", a.key), View.DragShadowBuilder(v), null, 0)
        v.alpha = 0.3f
        showSlotGuides()
    }

    private fun showSlotGuides() {
        for (pi in 0 until pagerBox.childCount) {
            val g = pagerBox.getChildAt(pi) as? GridView ?: continue
            for (ci in 0 until g.childCount) {
                val c = g.getChildAt(ci)
                if (c.tag == "empty") c.background = android.graphics.drawable.InsetDrawable(
                    GradientDrawable().apply { setColor(0x14FFFFFF); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0x33FFFFFF) }, dp(6))
            }
        }
    }

    private fun flip(p: Int) {
        cur = p; lastFlip = System.currentTimeMillis()
        pager.smoothScrollTo(p * pager.width, 0); drawDots()
    }

    private fun onDrag(ev: DragEvent): Boolean {
        when (ev.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                if (dragApp == null) return false
                glanceDate.text = "✕  拖到此处从桌面移除"; glanceWx.text = ""; glanceWx.setCompoundDrawables(null, null, null, null)
            }
            DragEvent.ACTION_DRAG_LOCATION -> {
                if (dragX0 < 0) { dragX0 = ev.x; dragY0 = ev.y }
                else if (Math.abs(ev.x - dragX0) + Math.abs(ev.y - dragY0) > dp(24)) dragMoved = true
                if (dragMoved && dragWhere == 0 && drawerOpen) openDrawer(false)
                if (System.currentTimeMillis() - lastFlip > 700) {
                    if (ev.x < dp(36) && cur > 0) flip(cur - 1)
                    else if (ev.x > root.width - dp(36) && cur < pageCount - 1) flip(cur + 1)
                }
            }
            DragEvent.ACTION_DROP -> drop(ev.x, ev.y)
            DragEvent.ACTION_DRAG_ENDED -> {
                updateGlance()
                val a = dragApp; dragApp = null
                refresh()
                if (a != null && !dragChanged && !dragMoved) menu(a, dragWhere)
            }
        }
        return true
    }

    private fun drop(x: Float, y: Float) {
        val a = dragApp ?: return
        val key = a.key
        val vis = all.map { it.key }.toSet() - list("hidden").toSet()
        val dl = list("dock"); val dv = dl.filter { it in vis }
        val nd = dv.toMutableList().apply { remove(key) }
        val slots = homeSlots(); val before = slots.toList()
        val old = slots.indexOf(key)
        var changed = false
        val rl = IntArray(2); root.getLocationInWindow(rl)
        when {
            y < home.getChildAt(0).bottom + dp(12) -> { if (old >= 0) slots[old] = "_" }   // 拖到顶部：移除
            y > dock.top -> {
                if (key.startsWith("dir:")) { Toast.makeText(this, "文件夹不能放进 Dock", Toast.LENGTH_SHORT).show(); return }
                if (nd.size >= docks[gi("dockN", 1)]) {
                    Toast.makeText(this, "Dock 已满", Toast.LENGTH_SHORT).show(); return
                }
                var idx = nd.size
                for (i in 0 until dock.childCount) {
                    val c = dock.getChildAt(i)
                    if (dock.left + c.left + c.width / 2 > x) { idx = i; break }
                }
                nd.add(idx.coerceAtMost(nd.size), key)
                if (old >= 0) slots[old] = "_"
            }
            else -> {
                val g = pagerBox.getChildAt(cur) as? GridView ?: return
                val gl = IntArray(2); g.getLocationInWindow(gl)
                val gx = (x - (gl[0] - rl[0])).toInt(); val gy = (y - (gl[1] - rl[1])).toInt()
                var pos = g.pointToPosition(gx, gy)
                if (pos < 0) {
                    val cw = maxOf(1, g.width / cols)
                    val ch = maxOf(1, (g.getChildAt(0)?.height ?: dp(100)) + dp(4))
                    pos = (gy / ch).coerceIn(0, rows - 1) * cols + (gx / cw).coerceIn(0, cols - 1)
                }
                val t = cur * cols * rows + pos
                while (slots.size <= t) slots.add("_")
                val other = slots[t]
                val isDir = key.startsWith("dir:")
                when {
                    other == "_" || other == key -> { if (old >= 0) slots[old] = "_"; slots[t] = key }
                    !isDir && other.startsWith("dir:") -> {            // 放进已有文件夹
                        val id = other.substring(4)
                        val l = dirMembers(id).toMutableList(); if (key !in l) l.add(key); saveDir(id, l)
                        if (old >= 0) slots[old] = "_"
                        changed = true
                    }
                    !isDir -> {                                         // 两个应用合并成新文件夹
                        val id = java.lang.Long.toString(System.currentTimeMillis(), 36)
                        saveDir(id, listOf(other, key))
                        slots[t] = "dir:" + id
                        if (old >= 0) slots[old] = "_"
                        changed = true
                    }
                    else -> {                                           // 文件夹之间交换位置
                        if (old >= 0) { slots[old] = other; slots[t] = key } else { slots[t] = key; slots[freeSlot(slots)] = other }
                    }
                }
            }
        }
        if (slots != before || nd != dv || changed) {
            saveSlots(slots); save("dock", nd + dl.filter { it !in vis })
            dragChanged = true
        }
    }

    private var drawerApps = listOf<App>()
    private fun refresh() {
        val hidden = list("hidden").toSet()
        val vis = all.filter { it.key !in hidden }
        val byKey = vis.associateBy { it.key }
        buildPages(homeSlots().map { slotApp(it, byKey) })
        dock.background = null
        updateGlance()
        pillV.visibility = if (sp.getBoolean("pill", true)) View.VISIBLE else View.GONE
        pillV.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xB32B3447.toInt(), 0x99202734.toInt())).apply { cornerRadius = dp(26).toFloat(); setStroke(dp(1), 0x22FFFFFF) }
        dock.removeAllViews()
        list("dock").mapNotNull { byKey[it] }.take(docks[gi("dockN", 1)]).forEach { a ->
            dock.addView(cell(a, 0xFFFFFFFF.toInt(), false).apply {
                setOnClickListener { launch(a, this) }
                setOnLongClickListener { v -> menuShown = true; startDrag(a, 2, v); true }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val tc = if (dark) 0xFFFFFFFF.toInt() else 0xFF1B1B1F.toInt()
        dGrid.setSelector(pressSel(dark))
        drawer.background = GradientDrawable().apply {
            setColor(mix(if (dark) 0xE6101014.toInt() else 0xE6FFFFFF.toInt(), accent, if (dark) 0.14f else 0.12f))
            cornerRadii = floatArrayOf(dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(), 0f, 0f, 0f, 0f)
        }
        search.setTextColor(tc); search.setHintTextColor(tc and 0x00FFFFFF or 0x88000000.toInt())
        search.background = glass(if (dark) 0x22FFFFFF else 0x14000000, 26).also { it.setStroke(dp(1), accent) }
        alignPill()
        refreshDrawer()
    }

    private fun alignPill() {
        val n = dock.childCount
        val dockMargin = dp(16)
        val inset = if (n <= 0) dp(4) else maxOf(0, ((resources.displayMetrics.widthPixels - dockMargin * 2) / n - dp(sizes[gi("size", 1)])) / 2)
        val lp = pillV.layoutParams as LinearLayout.LayoutParams
        val m = dockMargin + inset
        if (lp.leftMargin != m || lp.rightMargin != m) { lp.leftMargin = m; lp.rightMargin = m; pillV.layoutParams = lp }
    }

    private fun refreshDrawer() {
        val hidden = list("hidden").toSet()
        val q = search.text.toString().trim().lowercase()
        val vis = all.filter { it.key !in hidden }
        drawerApps = if (q.isEmpty()) vis else vis.filter {
            it.label.lowercase().contains(q) || it.py.contains(q) || it.ini.startsWith(q)
        }
        val tc = if (dark) 0xFFFFFFFF.toInt() else 0xFF1B1B1F.toInt()
        dGrid.numColumns = cols
        dGrid.adapter = Ad(drawerApps, tc)
        val idxMap = LinkedHashMap<Char, Int>()
        drawerApps.forEachIndexed { i, a ->
            val c = a.py.firstOrNull()?.uppercaseChar() ?: '#'
            val k = if (c in 'A'..'Z') c else '#'
            if (k !in idxMap) idxMap[k] = i
        }
        letterIndex = idxMap
        letterBar.letters = idxMap.keys.toList()
        letterBar.color = (tc and 0x00FFFFFF) or 0x99000000.toInt()
        letterBar.accentColor = accent
        letterBar.visibility = if (q.isEmpty() && idxMap.size > 1) View.VISIBLE else View.GONE
        letterBar.invalidate()
        recent.removeAllViews()
        if (q.isEmpty()) {
            val byKey = vis.associateBy { it.key }
            list("recent").mapNotNull { byKey[it] }.take(cols).forEach { a ->
                recent.addView(cell(a, tc).apply { setOnClickListener { launch(a, this) } }, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
        recentLabel.setTextColor((tc and 0x00FFFFFF) or 0x99000000.toInt())
        recentLabel.visibility = if (q.isEmpty() && recent.childCount > 0) View.VISIBLE else View.GONE
    }

    // ---------- 桌面文件夹 ----------
    private fun dirMembers(id: String): MutableList<String> = list("dir_" + id)
    private fun saveDir(id: String, l: List<String>) = save("dir_" + id, l)
    private fun dirName(id: String): String = sp.getString("dirn_" + id, null) ?: "文件夹"

    private fun slotApp(token: String, byKey: Map<String, App>): App? {
        if (!token.startsWith("dir:")) return byKey[token]
        val id = token.substring(4)
        val ms = dirMembers(id).mapNotNull { byKey[it] }
        if (ms.isEmpty()) return null
        return App(dirName(id), token, FolderIcon(ms.map { it.icon }), "", "")
    }

    private fun normalizeFolder(id: String) {
        val l = dirMembers(id).filter { k -> all.any { it.key == k } }
        if (l.size >= 2) { saveDir(id, l); return }
        val s = homeSlots(); val i = s.indexOf("dir:" + id)
        if (i >= 0) s[i] = if (l.size == 1) l[0] else "_"
        saveSlots(s); sp.edit().remove("dir_" + id).remove("dirn_" + id).apply()
    }

    private fun renameFolder(id: String, dlg: AlertDialog?) {
        val input = EditText(this).apply { setText(dirName(id)); setSingleLine(); setTextColor(INK); setSelectAllOnFocus(true) }
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("文件夹名称").setView(input)
            .setPositiveButton("确定") { _, _ ->
                sp.edit().putString("dirn_" + id, input.text.toString().trim().ifEmpty { "文件夹" }).apply()
                dlg?.dismiss(); refresh()
            }
            .setNegativeButton("取消", null).show()
    }

    private fun folderMenu(a: App) {
        val id = a.key.substring(4)
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle(a.label).setItems(arrayOf("重命名", "解散文件夹")) { _, i ->
            if (i == 0) renameFolder(id, null) else {
                val ms = dirMembers(id); val s = homeSlots(); val at = s.indexOf("dir:" + id)
                if (at >= 0) { s[at] = "_"; ms.forEachIndexed { n, k -> if (n == 0) s[at] = k else s[freeSlot(s)] = k } }
                saveSlots(s); sp.edit().remove("dir_" + id).remove("dirn_" + id).apply(); refresh()
            }
        }.show()
    }

    private fun folderMemberMenu(id: String, a: App, dlg: AlertDialog) {
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle(a.label).setItems(arrayOf("移出文件夹", "应用信息")) { _, i ->
            if (i == 0) {
                val l = dirMembers(id); l.remove(a.key); saveDir(id, l)
                val s = homeSlots(); val f = freeSlot(s); s[f] = a.key; saveSlots(s)
                normalizeFolder(id); dlg.dismiss(); refresh()
            } else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)))
        }.show()
    }

    private fun openFolder(id: String) {
        val members = dirMembers(id).mapNotNull { k -> all.firstOrNull { it.key == k } }
        if (members.isEmpty()) { normalizeFolder(id); refresh(); return }
        val lay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        val title = TextView(this).apply {
            text = dirName(id); textSize = 18f; setTextColor(INK); setPadding(dp(6), dp(4), 0, dp(8))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        lay.addView(title)
        val g = GridView(this).apply { numColumns = 4; setSelector(android.R.color.transparent); adapter = Ad(members, INK) }
        lay.addView(g)
        val dlg = AlertDialog.Builder(this, R.style.PixelDialog).setView(lay).create()
        g.setOnItemClickListener { _, v, p, _ -> dlg.dismiss(); launch(members[p], v) }
        g.setOnItemLongClickListener { _, _, p, _ -> folderMemberMenu(id, members[p], dlg); true }
        title.setOnClickListener { renameFolder(id, dlg) }
        dlg.show()
    }

    private fun launch(a: App, src: View? = null) {
        if (a.key.startsWith("dir:")) { openFolder(a.key.substring(4)); return }
        if (a.key in list("locked")) { requireAuth(a); return }
        launchNow(a, src)
    }

    private fun launchNow(a: App, src: View? = null) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName.unflattenFromString(a.key)!!).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val opts = try {
            if (src != null && src.width > 0) android.app.ActivityOptions.makeScaleUpAnimation(src, 0, 0, src.width, src.height).toBundle() else null
        } catch (e: Exception) { null }
        try { startActivity(i, opts) } catch (e: Exception) { Toast.makeText(this, "无法打开", Toast.LENGTH_SHORT).show() }
        val r = list("recent"); r.remove(a.key); r.add(0, a.key); save("recent", r.take(5))
        if (drawerOpen) root.postDelayed({ openDrawer(false) }, 300)
    }

    private fun menu(a: App, where: Int) {
        if (a.key.startsWith("dir:")) { folderMenu(a); return }
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items += "自定义图标 / 名称" to { customApp(a) }
        if (where == 0) {
            items += "添加到桌面" to { pin("home", a) }
            items += "添加到 Dock" to { pin("dock", a) }
        } else items += "从桌面移除" to { if (where == 1) clearFromHome(a.key) else { val l = list("dock"); l.remove(a.key); save("dock", l) }; refresh() }
        items += "隐藏" to {
            val h = list("hidden"); h.add(a.key); save("hidden", h)
            val dl = list("dock"); dl.remove(a.key); save("dock", dl); clearFromHome(a.key)
            refresh()
        }
        items += (if (a.key in list("locked")) "解除应用锁" else "加应用锁") to { toggleLock(a) }
        items += "应用信息" to { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg))) }
        items += "卸载" to { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))) }
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle(a.label).setItems(items.map { p -> p.first }.toTypedArray()) { _, i -> items[i].second() }.show()
    }

    private fun pin(k: String, a: App) {
        if (k == "home") {
            val sl = homeSlots()
            if (a.key !in sl) { val f = freeSlot(sl); sl[f] = a.key; saveSlots(sl) }
        } else {
            val l = list(k); if (a.key !in l) l.add(a.key); save(k, l)
        }
        refresh()
        Toast.makeText(this, "已添加", Toast.LENGTH_SHORT).show()
    }

    // ---------- 手势 / 动画 ----------
    private val upNames = listOf("打开抽屉", "无")
    private val downNames = listOf("通知栏", "打开搜索", "无")
    private val dblNames = listOf("无", "锁屏", "打开设置")
    private val animNames = listOf("快", "标准", "慢", "关闭")
    private val animScales = listOf(0.6f, 1f, 1.5f, 0f)
    private fun dur(ms: Long): Long = (ms * animScales[gi("anim", 1)]).toLong()

    private fun downGesture() {
        when (gi("g_down", 0)) {
            0 -> expandStatusBar()
            1 -> {
                openDrawer(true)
                search.post {
                    search.requestFocus()
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, 0)
                }
            }
        }
    }

    private fun expandStatusBar() {
        try {
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel")
                .invoke(getSystemService("statusbar"))
        } catch (e: Exception) { Toast.makeText(this, "此设备不支持下滑通知栏", Toast.LENGTH_SHORT).show() }
    }

    private fun lockScreen() {
        if (LockService.lock()) return
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("需要开启无障碍服务")
            .setMessage("双击锁屏需要在“无障碍”里开启「pixel桌面 锁屏」。该服务只执行锁屏动作，不会读取屏幕内容。")
            .setPositiveButton("去开启") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("取消", null).show()
    }

    private fun onEmptyHome(x: Float, y: Float): Boolean {
        if (drawerOpen || negativeOpen) return false
        val g = pagerBox.getChildAt(cur) as? GridView ?: return false
        val gl = IntArray(2); g.getLocationOnScreen(gl)
        val gx = (x - gl[0]).toInt(); val gy = (y - gl[1]).toInt()
        if (gx < 0 || gx > g.width || gy < 0 || gy > g.height) return false
        val pos = g.pointToPosition(gx, gy)
        return pos == AdapterView.INVALID_POSITION || (g.adapter as? SlotAd)?.data?.getOrNull(pos) == null
    }

    private fun cyc(k: String, n: Int, d: Int = 0) { sp.edit().putInt(k, (gi(k, d) + 1) % n).apply(); refresh() }

    private fun menuDialog(title: String, entries: () -> List<Pair<String, () -> Boolean>>) {
        val e = entries()
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle(title)
            .setItems(e.map { it.first }.toTypedArray()) { _, i -> if (e[i].second()) menuDialog(title, entries) }
            .show()
    }

    private fun onOff(k: String) = if (sp.getBoolean(k, true)) "开" else "关"

    private fun showSettings() {
        val top = listOf<Pair<String, () -> Unit>>(
            "🏠  桌面与图标" to { menuDialog("桌面与图标") { homeEntries() } },
            "🎨  外观与动画" to { menuDialog("外观与动画") { lookEntries() } },
            "👆  手势" to { menuDialog("手势") { gestureEntries() } },
            "🖼  壁纸" to { menuDialog("壁纸") { wallEntries() } },
            "📦  应用与负一屏" to { menuDialog("应用与负一屏") { appEntries() } },
            "💾  备份与系统" to { menuDialog("备份与系统") { sysEntries() } },
        )
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("pixel桌面 设置")
            .setItems(top.map { it.first }.toTypedArray()) { _, i -> top[i].second() }
            .setOnDismissListener { refresh() }.show()
    }

    private fun homeEntries(): List<Pair<String, () -> Boolean>> = listOf(
        "桌面布局：${cols}×${rows}" to { cyc("layout", layouts.size); true },
        "图标大小：${sizes[gi("size", 1)]}dp" to { cyc("size", sizes.size, 1); true },
        "图标形状：${shapes[gi("shape", 1)]}" to { cyc("shape", shapes.size, 1); true },
        "图标标签：${onOff("label")}" to { toggle("label"); true },
        "Dock 数量：${docks[gi("dockN", 1)]}" to { cyc("dockN", docks.size, 1); true },
        "页面指示器：${onOff("dots")}" to { toggle("dots"); true },
        "搜索栏：${if (sp.getBoolean("pill", true)) "显示" else "隐藏"}" to { toggle("pill"); true },
        "图标角标：${badgeNames[gi("badge", 0)]}" to {
            cyc("badge", badgeNames.size)
            if (gi("badge", 0) != 2 && !listenerEnabled()) {
                Toast.makeText(this, "请在列表里开启 pixel桌面 的通知使用权，角标才会显示", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            true
        },
    )

    private fun lookEntries(): List<Pair<String, () -> Boolean>> = listOf(
        "主题：${themes[gi("theme", 0)]}" to { cyc("theme", themes.size); true },
        "主题色：${tints[gi("tint", 0)]}" to { cyc("tint", tints.size); true },
        "壁纸模糊：${blurNames[gi("blur", 1)]}" to { cyc("blur", blurNames.size, 1); true },
        "动画速度：${animNames[gi("anim", 1)]}" to { cyc("anim", animNames.size, 1); true },
        "隐藏状态栏和导航栏：${if (sp.getBoolean("immersive", false)) "开" else "关"}" to {
            sp.edit().putBoolean("immersive", !sp.getBoolean("immersive", false)).apply(); applySystemBars(); true
        },
        "图标包：${packs().firstOrNull { it.second == packPkg }?.first ?: "系统默认"}" to { showPacks(); false },
    )

    private fun gestureEntries(): List<Pair<String, () -> Boolean>> = listOf(
        "上滑手势：${upNames[gi("g_up", 0)]}" to { cyc("g_up", upNames.size); true },
        "下滑手势：${downNames[gi("g_down", 0)]}" to { cyc("g_down", downNames.size); true },
        "双击手势：${dblNames[gi("g_dbl", 0)]}" to { cyc("g_dbl", dblNames.size); true },
    )

    private fun wallEntries(): List<Pair<String, () -> Boolean>> = listOf(
        "自定义壁纸（桌面 / 锁屏）" to { pickWallpaper(); false },
        "系统壁纸选择器" to { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "壁纸")); false },
    )

    private fun appEntries(): List<Pair<String, () -> Boolean>> = listOf(
        "添加小部件" to { showWidgetPicker(); false },
        "点击天气打开：${wxOpenNames[gi("wxopen", 0)]}" to { cyc("wxopen", wxOpenNames.size); true },
        "负一屏卡片显示" to { cardsManager(); false },
        "隐藏应用管理" to { hiddenManager(); false },
        "负一屏小部件管理" to { openNegative(true); false },
    )

    private fun sysEntries(): List<Pair<String, () -> Boolean>> = listOf(
        "备份到文件" to { backupToFile(); false },
        "从文件恢复" to { restoreFromFile(); false },
        "备份布局到剪贴板" to { backup(); false },
        "从剪贴板恢复布局" to { restore(); false },
        "设为默认桌面" to { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)); false },
    )

    private val reqWallpaper = 77
    private fun toggle(k: String) { sp.edit().putBoolean(k, !sp.getBoolean(k, true)).apply(); refresh() }

    private fun pickWallpaper() {
        try {
            startActivityForResult(Intent.createChooser(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), "选择壁纸"), reqWallpaper)
        } catch (e: Exception) { Toast.makeText(this, "找不到图片选择器", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == reqBackup && res == RESULT_OK) {
            val u = data?.data
            if (u != null) try {
                contentResolver.openOutputStream(u)?.use { it.write(prefsJson().toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "已备份到文件", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "备份失败", Toast.LENGTH_SHORT).show() }
            return
        }
        if (rc == reqRestore && res == RESULT_OK) {
            val u = data?.data
            if (u != null) try {
                val t = contentResolver.openInputStream(u)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                applyBackup(t)
                Toast.makeText(this, "已从文件恢复", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "这不是有效的备份文件", Toast.LENGTH_SHORT).show() }
            return
        }
        if (rc == reqAuth) {
            val a = authApp; authApp = null
            if (res == RESULT_OK && a != null) launchNow(a)
            return
        }
        if (rc == reqWidgetBind) {
            val id = pendingWidgetId
            if (res == RESULT_OK && id > 0) {
                val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
                if (info != null) finishAddWidget(id, info) else { widgetHost.deleteAppWidgetId(id); pendingWidgetId = -1 }
            } else if (id > 0) { widgetHost.deleteAppWidgetId(id); pendingWidgetId = -1 }
            return
        }
        if (rc == reqWidgetConfigure) {
            val id = pendingWidgetId
            if (id > 0 && res == RESULT_OK) saveWidget(id) else if (id > 0) widgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1; return
        }
        if (rc == reqAppIcon) {
            if (res == RESULT_OK) {
                val uri = data?.data
                if (uri != null && pendingAppKey.isNotEmpty()) {
                    try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
                    sp.edit().putString("icon:$pendingAppKey", uri.toString()).apply(); load(); refresh()
                }
            }
            pendingAppKey = ""; return
        }
        if (rc != reqWallpaper || res != RESULT_OK) return
        val uri = data?.data ?: return
        val labels = arrayOf("桌面", "锁屏", "桌面和锁屏")
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("设为").setItems(labels) { _, i ->
            val flag = when (i) {
                0 -> WallpaperManager.FLAG_SYSTEM
                1 -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            Thread {
                val ok = try {
                    contentResolver.openInputStream(uri)?.use { WallpaperManager.getInstance(this).setStream(it, null, true, flag) }
                    true
                } catch (e: Exception) { false }
                runOnUiThread { Toast.makeText(this, if (ok) "壁纸已设置" else "设置失败", Toast.LENGTH_SHORT).show() }
            }.start()
        }.show()
    }

    private fun hiddenManager() {
        val hidden = list("hidden").toSet()
        val checked = BooleanArray(all.size) { all[it].key in hidden }
        AlertDialog.Builder(this, R.style.PixelDialog).setTitle("隐藏应用")
            .setMultiChoiceItems(all.map { it.label }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("完成") { _, _ -> save("hidden", all.filterIndexed { i, _ -> checked[i] }.map { it.key }); refresh() }
            .show()
    }

    private fun openDrawer(o: Boolean) {
        if (o && negativeOpen) openNegative(false)
        drawerOpen = o
        animateBlur(o)
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (o) {
            search.setText("")
            refreshDrawer()
            if (drawer.visibility != View.VISIBLE) drawer.translationY = root.height.toFloat()
            drawer.visibility = View.VISIBLE
            drawer.animate().translationY(0f).setDuration(dur(320)).setInterpolator(DecelerateInterpolator()).start()
            home.animate().alpha(0.35f).scaleX(0.94f).scaleY(0.94f).setDuration(dur(320)).start()
        } else {
            imm.hideSoftInputFromWindow(search.windowToken, 0)
            drawer.animate().translationY(root.height.toFloat()).setDuration(dur(260))
                .withEndAction { drawer.visibility = View.GONE }.start()
            home.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(dur(260)).start()
        }
    }
}

private class GoogleG(private val size: Int) : android.graphics.drawable.Drawable() {
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE }
    override fun draw(c: android.graphics.Canvas) {
        val w = size * 0.2f
        p.strokeWidth = w
        val h = w / 2f
        val box = android.graphics.RectF(h, h, size - h, size - h)
        p.color = 0xFFEA4335.toInt(); c.drawArc(box, 215f, 105f, false, p)
        p.color = 0xFFFBBC05.toInt(); c.drawArc(box, 135f, 80f, false, p)
        p.color = 0xFF34A853.toInt(); c.drawArc(box, 45f, 90f, false, p)
        p.color = 0xFF4285F4.toInt(); c.drawArc(box, 0f, 45f, false, p)
        c.drawLine(size / 2f, size / 2f, size.toFloat(), size / 2f, p)
    }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    override fun getIntrinsicWidth(): Int = size
    override fun getIntrinsicHeight(): Int = size
}

private class PillIcons(private val u: Int) : android.graphics.drawable.Drawable() {
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { strokeCap = android.graphics.Paint.Cap.ROUND; color = 0xFFFFFFFF.toInt() }
    override fun draw(c: android.graphics.Canvas) {
        val s = u.toFloat()
        p.strokeWidth = s * 0.09f
        p.style = android.graphics.Paint.Style.FILL
        c.drawRoundRect(android.graphics.RectF(s * 0.36f, s * 0.08f, s * 0.64f, s * 0.58f), s * 0.14f, s * 0.14f, p)
        p.style = android.graphics.Paint.Style.STROKE
        c.drawArc(android.graphics.RectF(s * 0.22f, s * 0.28f, s * 0.78f, s * 0.76f), 0f, 180f, false, p)
        c.drawLine(s * 0.5f, s * 0.76f, s * 0.5f, s * 0.92f, p)
        val o = s * 1.7f
        c.drawRoundRect(android.graphics.RectF(o + s * 0.1f, s * 0.1f, o + s * 0.9f, s * 0.9f), s * 0.2f, s * 0.2f, p)
        c.drawCircle(o + s * 0.5f, s * 0.5f, s * 0.16f, p)
    }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    override fun getIntrinsicWidth(): Int = (u * 2.7f).toInt()
    override fun getIntrinsicHeight(): Int = u
}

private class FolderIcon(src: List<android.graphics.drawable.Drawable>) : android.graphics.drawable.Drawable() {
    private val copies = src.take(4).map { it.constantState?.newDrawable()?.mutate() ?: it }
    private val bg = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF }
    private val edge = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        style = android.graphics.Paint.Style.STROKE; color = 0x55FFFFFF; strokeWidth = 2f
    }
    override fun draw(c: android.graphics.Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val box = android.graphics.RectF(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat())
        c.drawRoundRect(box, w * 0.28f, w * 0.28f, bg)
        c.drawRoundRect(box, w * 0.28f, w * 0.28f, edge)
        val pad = w * 0.12f
        val cell = (w - pad * 2f) / 2f
        val ic = cell * 0.86f
        val gap = (cell - ic) / 2f
        copies.forEachIndexed { i, d ->
            val x = b.left + pad + (i % 2) * cell + gap
            val y = b.top + pad + (i / 2) * cell + gap
            d.setBounds(x.toInt(), y.toInt(), (x + ic).toInt(), (y + ic).toInt())
            d.draw(c)
        }
    }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}

private class LetterBar(c: Context) : View(c) {
    var letters: List<Char> = emptyList()
    var color = 0x99FFFFFF.toInt()
    var accentColor = 0xFF9DB7FF.toInt()
    var active = -1
    var onPick: (Char, Boolean) -> Unit = { _, _ -> }
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textAlign = android.graphics.Paint.Align.CENTER }
    override fun onDraw(cv: android.graphics.Canvas) {
        if (letters.isEmpty()) return
        val h = height.toFloat() / letters.size
        p.textSize = minOf(h * 0.72f, width * 0.62f)
        for (i in letters.indices) {
            p.color = if (i == active) accentColor else color
            p.isFakeBoldText = i == active
            cv.drawText(letters[i].toString(), width / 2f, h * i + h / 2f + p.textSize * 0.35f, p)
        }
    }
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (letters.isEmpty()) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val i = (ev.y / height * letters.size).toInt().coerceIn(0, letters.size - 1)
                if (i != active) { active = i; invalidate(); onPick(letters[i], true) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { active = -1; invalidate(); onPick(' ', false) }
        }
        return true
    }
}
