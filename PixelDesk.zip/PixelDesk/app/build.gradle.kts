plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.pixel.desk"
    compileSdk = 34
    defaultConfig { applicationId = "com.pixel.desk"; minSdk = 29; targetSdk = 34; versionCode = 20; versionName = "2.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
