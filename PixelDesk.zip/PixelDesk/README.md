# pixel桌面 2.0

本版本基于原 PixelDesk 源码增强，面向 Pixel 7 等 Android 手机。

## 新增
- 长按任意应用 → 自定义图标 / 名称
- 从相册选择单独图标
- 从当前图标包选择单独图标
- 每个应用独立保存桌面名称
- 恢复单个应用默认图标/名称
- 向右滑进入负一屏
- 负一屏支持 Android 系统 AppWidget
- 添加多个小部件
- 小部件长按删除
- 小部件 ID 持久化
- 修复 SharedPreferences 中 String/Integer 类型不一致造成的启动闪退

## 编译
Android Studio 打开本目录，使用 JDK 17。
compileSdk 34 / targetSdk 34 / minSdk 29。

生成 APK：Build → Build APK(s)。

天气图标：res/drawable/wx_*.xml 提取自用户提供的 WeatherMaster 应用，公开发布前请确认其授权。
