# pixel桌面（核心版）
1. 用 Android Studio（Hedgehog 2023.1 及以上，自带 JDK 17）打开本文件夹，等待 Gradle 同步。
2. 菜单 Build → Build Bundle(s) / APK(s) → Build APK(s)，APK 在 app/build/outputs/apk/debug/。
3. 安装后按 Home 键，选择「pixel桌面」→ 始终。
4. 长按桌面空白处进入设置。
遇到编译报错，把完整报错发回即可。
